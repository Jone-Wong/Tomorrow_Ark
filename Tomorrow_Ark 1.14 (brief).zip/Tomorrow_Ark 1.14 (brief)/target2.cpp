#include "target2.h"
#include <QVector2D>

Target2::Target2(QPoint startPos, QPoint endPos, QString fileName) : QObject(0), pixmap(fileName)
{

    //设置_敌人2-小车_的初始位置、末端位置、目前位置
    this->currentPos = startPos;
    this->startPos = startPos;
    this->endPos = endPos;

    speed = 5.0;
}

void Target2::move(){
    QVector2D vector(endPos - startPos);
    vector.normalize();
    currentPos = currentPos + vector.toPoint() * speed;

}

void Target2::draw(QPainter * painter){
    painter -> drawPixmap(currentPos, pixmap);
}
