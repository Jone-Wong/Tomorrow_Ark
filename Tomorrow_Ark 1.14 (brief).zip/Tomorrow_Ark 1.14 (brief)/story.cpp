#include "story.h"
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>
#include <QTimer>
#include "s2c_button.h"

Story::Story(QWidget *parent) : QMainWindow(parent)
{
    //设置选择关卡界面大小
    this->setFixedSize(1280,720);

    //设置返回按钮
    S2C_Button * back_btn = new S2C_Button(":/image/stry_button.png");
    back_btn->setParent(this);

    //返回按钮位置
    back_btn->move(1180,20);

    //返回按钮链接主界面，以及弹跳效果
    connect(back_btn,&S2C_Button::clicked,this,[=](){

        //弹跳效果
        back_btn->zoomdown();
        back_btn->zoomup();

        //设置延时，以便看到效果
        QTimer::singleShot(300,this,[=](){
            emit chooseBack();
        });
    });
}

void Story::paintEvent(QPaintEvent *){

    //选择关卡界面
    QPainter painter(this);

    //导入选择关卡界面图片
    QPixmap pixmap(":/image/story.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}

