#ifndef LEVONE_BUTTON_H
#define LEVONE_BUTTON_H

#include <QWidget>
#include <QPushButton>

class Levone_Button : public QPushButton
{
    Q_OBJECT
public:
    Levone_Button(QString pix);
    void zoomup();
    void zoomdown();

signals:

};

#endif // LEVONE_BUTTON_H
