#include "tower1.h"
#include <QPoint>
#include <QPixmap>
#include <QPainter>

Tower1::Tower1(QPoint pos, QString pixFileName) : QObject(0), pixmap(pixFileName)
{

    //设置_塔1-阿米娅_的位置
    _pos = pos;
}

void Tower1::draw(QPainter *painter){

    //画出_塔1-阿米娅_
    painter->drawPixmap(_pos, pixmap);
}
