#ifndef LEVELTWO_H
#define LEVELTWO_H

#include <QMainWindow>
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include "tower1.h"
#include <QList>
#include "target1.h"


class LevelTwo : public QMainWindow
{
    Q_OBJECT
public:
    explicit LevelTwo(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);
    void set_tower1();
    void addTarget();
    void updateScence();

private:
    QList<Tower1 *> tower1_list;
    QList<Target1*> target1_list;

signals:


};

#endif // LEVELTWO_H
