#include "target1.h"

Target1::Target1(QPoint startPos, QPoint endPos, QString fileName) : QObject(0), pixmap(fileName)
{

    //设置_敌人1-小车_的初始位置、末端位置、目前位置
    this->currentPos = startPos;
    this->startPos = startPos;
    this->endPos = endPos;
}

void Target1::draw(QPainter *painter){

    //画出_敌人1-小车_
    painter -> drawPixmap(currentPos, pixmap);
}

void Target1::move(){

    //选择动画效果
    QPropertyAnimation * animation = new QPropertyAnimation(this, "currentPos");

    //设置动画时长
    animation->setDuration(10000);

    //设置动画开始位置
    animation->setStartValue(startPos);

    //设置动画结束位置
    animation->setEndValue(endPos);

    //让动画开始
    animation->start();
}

QPoint Target1::getCurrentPos(){

    //得到_敌人1-小车_的目前位置
    return this->currentPos;
}

void Target1::setCurrentPos(QPoint Pos){

    //设置_敌人1-小车_的目前位置
    this->currentPos = Pos;
}
