#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMainWindow>
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>
#include <QTimer>
#include <QMovie>
#include "s2c_button.h"
#include "chooselevel.h"
#include "levone_button.h"
#include "levelone.h"
#include "settvr_button.h"
#include "story.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    //设置游戏界面窗口大小
    this->setFixedSize(1024,576);
    ui->setupUi(this);

    //设置主界面背景动画
    movie = new QMovie(this);

    //文件较大，故使用相对路径/////////导出程序时不要忘记附带视频///////////
    movie->setFileName(QString("../welcome.gif"));

    //开始播放
    movie->start();

    //计时，并定时刷新界面，保证流畅性
    QTimer * timer = new QTimer (this);
    connect (timer, &QTimer::timeout, this, &MainWindow::updateScence);
    timer->start(10);

    //设置一个按钮
    S2C_Button * btn = new S2C_Button(":/image/button.png");

    //设置背景故事跳转按钮
    S2C_Button * sbtn = new S2C_Button(":/image/stry_button.png");

    //设置按钮的父类和位置
    btn->setParent(this);
    btn->move(445,375);

    //设置父类及位置
    sbtn -> setParent(this);
    sbtn -> move(930,400);

    //创建选择关卡页面
    ChooseLevel * scene = new ChooseLevel;

    //创建故事背景介绍页面
    Story * exp = new Story;

    //设置按钮弹跳效果
    connect(btn,&QPushButton::clicked,this,[=](){

        //弹跳效果
        btn->zoomdown();
        btn->zoomup();

        //设置时间间隔
        QTimer::singleShot(300,this,[=](){

            //界面的隐藏和显现
            this->hide();
            scene->show();
        });
    });

    connect(sbtn, &QPushButton::clicked,this,[=](){

        //按钮弹跳效果
        sbtn -> zoomdown();
        sbtn -> zoomup();

        //设置延后效果
        QTimer::singleShot(300,this,[=](){

            this->hide();
            exp->show();
        });
    });

    //由选择关卡界面返回主界面按钮
    connect(scene,&ChooseLevel::chooseBack,this,[=](){

        //界面的隐藏和显现
        scene->hide();
        this->show();
    });

    //由选择关卡界面返回主界面按钮
    connect(exp,&Story::chooseBack,this,[=](){


        //界面的隐藏和显现
        exp->hide();
        this->show();
    });

    //导入第一关按钮图像
    Levone_Button * lvonebtn = new Levone_Button(":/image/level_one.png");

    //设置第一关按钮父类和位置
    lvonebtn->setParent(scene);
    lvonebtn->move(80,100);

    //设置第一关背景
    LevelOne * levone = new LevelOne;

    connect(lvonebtn,&QPushButton::clicked,this,[=](){

        //第一关按钮弹跳效果
        lvonebtn->zoomdown();
        lvonebtn->zoomup();

        //设置时间间隔
        QTimer::singleShot(300,this,[=](){

            //画面的隐藏与显现
            this->hide();
            levone->show();
        });
    });


}

void MainWindow::paintEvent(QPaintEvent *event){

    //主界面
    QPainter painter(this);

    //导入主界面背景
    event = new QPaintEvent(QRect(0,0,this->width(),this->height()));
    painter.drawPixmap(0,0,width(),height(), movie->currentPixmap());

    showInfo(&painter);
}

void MainWindow::showInfo(QPainter * painter){

    //保存画笔
    painter -> save();

    //设置画笔
    painter -> setPen(Qt::white);

    //设置位置、内容
    painter -> drawText(QRect(340,540,500,100),QString("Copy Right @ Wang Kaixin , June 6 , 2020  _Version 1.13_"));

    //还原画笔
    painter -> restore();
}


void MainWindow::updateScence(){

    //刷新
    update();
}


MainWindow::~MainWindow()
{
    delete ui;
}
