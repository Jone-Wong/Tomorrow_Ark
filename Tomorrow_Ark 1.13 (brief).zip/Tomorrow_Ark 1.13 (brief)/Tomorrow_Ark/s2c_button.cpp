#include "s2c_button.h"
#include <QPixmap>
#include <QPushButton>
#include <QPropertyAnimation>

S2C_Button::S2C_Button(QString pix):QPushButton(0){

    //设置按钮
    QPixmap pixmap(pix);

    //按钮大小由图片本身决定
    this->setFixedSize(pixmap.width(),pixmap.height());
    this->setStyleSheet("QPushButton{border:0px;}");
    this->setIcon(pixmap);
    this->setIconSize(QSize(pixmap.width(),pixmap.height()));
}

void S2C_Button::zoomdown(){

    //按钮下跳的实现
    QPropertyAnimation * animation = new QPropertyAnimation(this,"geometry");

    //按钮跳动时长
    animation->setDuration(100);

    //按钮跳动范围
    animation->setStartValue(QRect(this->x(),this->y(),this->width(),this->height()));
    animation->setEndValue(QRect(this->x(),this->y()+5,this->width(),this->height()));

    //引入动画
    animation->setEasingCurve(QEasingCurve::OutBounce);

    //开始跳动
    animation->start();
}

void S2C_Button::zoomup(){

    //按钮上跳的实现
    QPropertyAnimation * animation = new QPropertyAnimation(this,"geometry");

    //按钮上跳的时长
    animation->setDuration(100);

    //按钮上跳的范围
    animation->setStartValue(QRect(this->x(),this->y()+5,this->width(),this->height()));
    animation->setEndValue(QRect(this->x(),this->y(),this->width(),this->height()));

    //引入动画
    animation->setEasingCurve(QEasingCurve::OutBounce);

    //开始跳动
    animation->start();
}
