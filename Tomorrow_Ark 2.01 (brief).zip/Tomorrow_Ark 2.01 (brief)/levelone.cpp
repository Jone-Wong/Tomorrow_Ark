#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include "levelone.h"
#include <QTimer>
#include "tower1.h"
#include "waypoint.h"
#include "towerposition.h"
#include "target1.h"
#include "bullet.h"
#include "selectioncircle.h"
#include "settvr_button.h"

LevelOne::LevelOne(QWidget *parent) : QMainWindow(parent)
{
    setFixedSize(1024,576);
    //    mybutton * back_btn = new mybutton(":/pictures/pictures/return0.jpg");
    //    back_btn->setParent(this);
    //    back_btn->move(100,40);
    //    connect(back_btn,&mybutton::clicked,this,[=](){
    //        emit chooseBack();
    //    });
    loadTowerPositions();
    addWayPoints();
    //    loadWave();

    Settvr_Button * startwave = new Settvr_Button(":/image/settower_button.png");
    startwave->setParent(this);
    startwave->move(660, 0);
    connect(startwave, SIGNAL(clicked()), this, SLOT(triggerwave()));

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(updateMap()));
    timer->start(10);
}

void LevelOne::paintEvent(QPaintEvent *)
{
    if (m_gameEnd || m_gameWin)
    {
        QString text = m_gameEnd ? "Mission Failed!!!" : "Mission Accomplished!!!";
        QPainter painter(this);
        painter.setPen(QPen(Qt::red));
        painter.drawText(rect(), Qt::AlignCenter, text);
        return;
    }

    QPainter painter(this);

    QPixmap p1(":/image/levone_bg.png");
    painter.drawPixmap(0,0,1024,576,p1);

    showInfo(&painter);

    foreach(const TowerPosition &towerPos, m_towerPositionsList)
        towerPos.draw(&painter);

    foreach(Tower1 *tower, tower1_list)
        tower->draw(&painter);

    foreach(WayPoint *wp, m_wayPointsList1)
        wp->draw(&painter);

    foreach(WayPoint *wp, m_wayPointsList2)
        wp->draw(&painter);

    foreach(WayPoint *wp, m_wayPointsList3)
        wp->draw(&painter);

    foreach(Target1 *enemy, target1_list)
        enemy->draw(&painter);

    foreach (Bullet *bullet, m_bulletList)
        bullet->draw(&painter);

}

void LevelOne::updateMap()
{
    foreach (Target1 *enemy, target1_list)
        enemy->move();
    foreach (Tower1 *tower, tower1_list)
        tower->checkEnemyInRange();
    update();
}

void LevelOne::triggerwave()
{
    loadWave();
}

void LevelOne::showInfo(QPainter *painter)
{
    painter->save();
    painter->setPen(Qt::white);
    painter->drawText(QRect(385,5,2000,50),QString("源石 : %1    侵略 : %2    守卫建筑生命 : %3").arg(fee).arg(m_waves).arg(health));
    painter->restore();
}

void LevelOne::loadTowerPositions()
{
    QPoint pos[] =
    {
        QPoint(205,114),
        QPoint(280,114),
        QPoint(355,114),

        QPoint(435,114),
        QPoint(510,114),
        QPoint(585,114),

        QPoint(665,114),
        QPoint(740,114),
        QPoint(815,114),

        QPoint(135,399),
        QPoint(225,399),
        QPoint(315,399),

        QPoint(419,399),
        QPoint(509,399),
        QPoint(599,399),

        QPoint(704,399),
        QPoint(794,399),
        QPoint(884,399),
    };
    int len	= sizeof(pos) / sizeof(pos[0]);

    for (int i = 0; i < len; ++i)
        m_towerPositionsList.push_back(pos[i]);
}

void LevelOne::mousePressEvent(QMouseEvent *event)
{
    QPoint pressPos = event->pos();
    auto it = m_towerPositionsList.begin();
    while (it != m_towerPositionsList.end())
    {
        if (canBuyTower() && it->containPoint(pressPos) && !it->hasTower())
        {
            it->setHasTower();
            fee-=2;
            QPoint centerpoint=it->centerPos();
            SelectionCircle *c = new SelectionCircle(it->centerPos(),":/pictures/pictures/selectioncircle.png");
            QPainter painter(this);
            c->draw(&painter);
            Tower1 *tower1 = new Tower1(centerpoint,this,":/image/tower1.png");
            tower1_list.push_back(tower1);
            update();
            break;
        }
        ++it;
    }
}

bool LevelOne::canBuyTower() const
{
    if (fee >= 2)
        return true;
    return false;
}

void LevelOne::addWayPoints()
{
    WayPoint *wayPoint1 = new WayPoint(QPoint(100, 185));
    m_wayPointsList1.push_back(wayPoint1);

    WayPoint *wayPoint2 = new WayPoint(QPoint(900, 185));
    m_wayPointsList1.push_back(wayPoint2);
    wayPoint2->setNextWayPoint(wayPoint1);

    WayPoint *wayPoint3 = new WayPoint(QPoint(75, 260));
    m_wayPointsList2.push_back(wayPoint3);

    WayPoint *wayPoint4 = new WayPoint(QPoint(925, 260));
    m_wayPointsList2.push_back(wayPoint4);
    wayPoint4->setNextWayPoint(wayPoint3);

    WayPoint *wayPoint5 = new WayPoint(QPoint(50, 330));
    m_wayPointsList3.push_back(wayPoint5);

    WayPoint *wayPoint6 = new WayPoint(QPoint(950, 330));
    m_wayPointsList3.push_back(wayPoint6);
    wayPoint6->setNextWayPoint(wayPoint5);
}

void LevelOne::getHpDamage(int damage = 1)
{
    health-=damage;

    if (health <= 0)
        doGameOver();

}

void LevelOne::removedEnemy(Target1 *enemy)
{
    Q_ASSERT(enemy);
    target1_list.removeOne(enemy);
    delete enemy;
    if (target1_list.empty())
    {
        ++m_waves;                                          // 当前波数加1
                                                                     // 继续读取下一波
        if (!loadWave())
        {
                                                                    // 当没有下一波时，这里表示游戏胜利
                                                                    // 设置游戏胜利标志为true
            m_gameWin = true;
        }
    }
}

bool LevelOne::loadWave()
{
    if (m_waves >= 3)
        return false;
    WayPoint *startWayPoint1 = m_wayPointsList1.back(); // 这里是个逆序的，尾部才是其实节点
    WayPoint *startWayPoint2 = m_wayPointsList2.back();
    WayPoint *startWayPoint3 = m_wayPointsList3.back();
    int enemyStartInterval[] = { 1000,3000,5000,6000,7000,8000 };
    for (int i = 0; i < 6; ++i)
    {
        Target1 *enemy1 = new Target1(startWayPoint1, this, ":/image/target1.png");
        Target1 *enemy2 = new Target1(startWayPoint2, this, ":/image/target1.png");
        Target1 *enemy3 = new Target1(startWayPoint3, this, ":/image/target1.png");
        target1_list.push_back(enemy1);
        QTimer::singleShot(enemyStartInterval[i], enemy1, SLOT(doActivate()));
        target1_list.push_back(enemy2);
        QTimer::singleShot(enemyStartInterval[i], enemy2, SLOT(doActivate()));
        target1_list.push_back(enemy3);
        QTimer::singleShot(enemyStartInterval[i], enemy3, SLOT(doActivate()));
    }
    return true;
}

void LevelOne::addBullet(Bullet *bullet)
{
    Q_ASSERT(bullet);

    m_bulletList.push_back(bullet);
}

void LevelOne::removedBullet(Bullet *bullet)
{
    Q_ASSERT(bullet);
    m_bulletList.removeOne(bullet);
    delete bullet;
}

void LevelOne::awardgold(int gold)
{
    fee+=gold;
}

QList<Target1 *> LevelOne::enemyList() const
{
    return target1_list;
}

void LevelOne::doGameOver()
{
    m_gameEnd=true;
}
