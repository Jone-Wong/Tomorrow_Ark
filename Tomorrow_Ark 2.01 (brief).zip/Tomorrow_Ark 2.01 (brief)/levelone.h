#ifndef LEVELONE_H
#define LEVELONE_H

#include <QMainWindow>
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QList>
#include "target1.h"
#include "towerposition.h"
#include "tower1.h"

class Target1;
class WayPoint;
class Bullet;
class Settvr_Button;

class LevelOne : public QMainWindow
{
    Q_OBJECT
public:
   explicit LevelOne(QWidget *parent = nullptr);
   void paintEvent(QPaintEvent*);
   void showInfo(QPainter *);
   void loadTowerPositions();

   bool canBuyTower() const;
   void addWayPoints();
   void getHpDamage(int damage/* = 1*/);
   void mousePressEvent(QMouseEvent *event);


   void removedEnemy(Target1 *enemy);
   bool loadWave();
   void addBullet(Bullet * b);
   QList<Target1 *> enemyList() const;
   void removedBullet(Bullet *bullet);
   void awardgold(int gold);
   void doGameOver();

//   void set_tower1();
//   void addTarget();
//   void updateScence();

public slots:
   void updateMap();
   void triggerwave();

private:
   int fee = 100;
   int m_waves = 1;
   int health = 50;
   bool m_gameWin = false;
   bool m_gameEnd = false;
   QList<Tower1 *> tower1_list;
   QList<Target1*> target1_list;
   QList<TowerPosition> m_towerPositionsList;
   QList<WayPoint *> m_wayPointsList1;
   QList<WayPoint *> m_wayPointsList2;
   QList<WayPoint *> m_wayPointsList3;
   QList<Bullet *>	m_bulletList;

signals:

};

#endif // LEVELONE_H



//    void mousePressEvent(QMouseEvent *event);

//private:
//    int fee = 1000;
//    int m_waves = 1;
//    int mingdehealth=3;
//    bool m_gameWin = false;
//    bool m_gameEnd = false;
//    QList<TowerPosition> m_towerPositionsList;
//    QList<tower*> m_towersList;
//    QList<WayPoint *> m_wayPointsList;
//    QList<Enemy *> m_enemyList;	// 记得需要在paintEvent中进行绘制
//    QList<Bullet *>	m_bulletList;
//signals:
//    void chooseBack();
//};
