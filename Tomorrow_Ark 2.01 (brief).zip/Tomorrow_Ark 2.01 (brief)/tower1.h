#ifndef TOWER1_H
#define TOWER1_H

#include <QObject>
#include <QPoint>
#include <QPixmap>
#include "bullet.h"

class Target1;
class LevelOne;
class Bullet;

class Tower1 : QObject
{
    Q_OBJECT

public:
    Tower1(QPoint pos, LevelOne *game,QString pixfilename);
    void draw(QPainter * painter);
    void targetKilled();
    void attackEnemy();
    void chooseEnemyForAttack(Target1 * enemy);
    void lostSightOfEnemy();
    void checkEnemyInRange();

public slots:
    void shootWeapon();

private:
    QPoint pos;
    bool mattacking;
    QSize ms_fixedSize;
    QPixmap pixmap;
    int firerange;
    int damage;
    int firerate;
    double mrotationpixmap;
    Target1 * mchooseEnemy;
    QTimer * mfireRateTimer;
    LevelOne * mgame;
signals:
};

#endif // TOWER1_H


/*

#include <QObject>
#include<QPoint>
#include<QPixmap>

class Enemy;
class battlefield1;
class tower: QObject
{
    Q_OBJECT
public:
    tower(QPoint pos, battlefield1 *game,QString pixfilename);
    void draw(QPainter * painter);
    void targetKilled();
    void attackEnemy();
    void chooseEnemyForAttack(Enemy * enemy);
    void lostSightOfEnemy();
    void checkEnemyInRange();
public slots:
    void shootWeapon();
private:
    QPoint pos;
    bool mattacking;
    QSize ms_fixedSize;
    QPixmap pixmap;
    int firerange;
    int damage;
    int firerate;
    double mrotationpixmap;
    Enemy * mchooseEnemy;
    QTimer * mfireRateTimer;
    battlefield1 * mgame;
signals:
};

*/
