#include "selectioncircle.h"

SelectionCircle::SelectionCircle(QPoint mpos, QString filename) : QObject(0)
{
    this->pos=mpos;
    QPixmap p(filename);
    size=QSize(p.width(),p.height());
    pixmap=p;
}

void SelectionCircle::draw(QPainter *painter)
{
    painter -> drawPixmap(pos.x(),pos.y(),pixmap);
}
