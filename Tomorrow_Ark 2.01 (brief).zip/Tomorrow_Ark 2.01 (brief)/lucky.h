#ifndef LUCKY_H
#define LUCKY_H

#include <QMainWindow>
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QObject>
#include <QPoint>
#include <QList>

class Show_Card;

class Lucky : public QMainWindow
{
    Q_OBJECT
public:
    explicit Lucky(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);

signals:
    void chooseBack();

};

class Alipay : public QMainWindow
{
    Q_OBJECT
public:
    explicit Alipay(QWidget *parent = nullptr);
     void paintEvent(QPaintEvent*);
};

class Fdcard : public QMainWindow
{
    Q_OBJECT
public:
    explicit Fdcard(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);
    void showInfo(QPainter * painter);
    void showCard();

private:
    QList<Show_Card *> Card_list;

signals:
    void chooseBack();
};

class Show_Card : public QObject
{
    Q_OBJECT
public:
    Show_Card(QPoint pos, QString pixFileName);
    void draw(QPainter *);
private:
    QPoint _pos;
    QPixmap pixmap;

signals:

};

#endif // LUCKY_H
