#ifndef EXPLODE_H
#define EXPLODE_H

#include <QObject>
#include <QPoint>
#include "levelone.h"

class LevelOne;

class Explode : public QObject
{
    Q_OBJECT
public:
    Explode(QPoint pos, LevelOne * game, QString filename);
    QPoint showpos();
    QString showpicture();
private:
    QPoint mpos;
    LevelOne * m_game;
    QString filename;
public slots:
    void deleteexplode();
};

#endif // EXPLODE_H
