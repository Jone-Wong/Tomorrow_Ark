#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QMediaPlayer>
#include "levelone.h"
#include <QTimer>
#include "tower1.h"
#include "waypoint.h"
#include "towerposition.h"
#include "target1.h"
#include "target1_1.h"
#include "target1_2.h"
#include "bullet.h"
#include "selectioncircle.h"
#include "settvr_button.h"
#include "s2c_button.h"
#include "tower1_1.h"
#include "tower1_2.h"
#include "tower1_3.h"
#include "tower1_4.h"
#include "tower1_1upgrade.h"
#include "tower1_2upgrade.h"

//产生随机数
#define random(x) (rand()%x)


LevelOne::LevelOne(QWidget *parent) : QMainWindow(parent)
{

    //设置界面大小
    setFixedSize(1024,576);

    //设置返回按钮
    S2C_Button *back_btn = new S2C_Button(":/image/back2cl.png");

    //设置按钮父类
    back_btn->setParent(this);

    //返回按钮位置
    back_btn->move(700,0);

    //返回按钮链接主界面，以及弹跳效果
    connect(back_btn,&S2C_Button::clicked,this,[=](){

        //弹跳效果
        back_btn->zoomdown();
        back_btn->zoomup();

        //设置延时，以便看到效果
        QTimer::singleShot(300,this,[=](){
            emit chooseBack();
        });
    });

    //加载塔位置
    loadTowerPositions();

    //加载路径点
    addWayPoints();

    loadselectioncircle();

    loaduandd();

    //设置敌人开始进入按钮
    Settvr_Button * startwave = new Settvr_Button(":/image/settower_button.png");

    //设置按钮父类
    startwave->setParent(this);

    //设置按钮位置
    startwave->move(660, 0);

    //点击按钮链接的操作
    connect(startwave, SIGNAL(clicked()), this, SLOT(triggerwave()));

    //设置计时，不断刷新界面
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(updateMap()));
    timer->start(10);
}

void LevelOne::paintEvent(QPaintEvent *)
{
    //判断游戏是否结束
    if (m_gameEnd || m_gameWin)
    {

        //输出任务完成或任务失败
        QString text = m_gameEnd ? "Mission Failed!!!" : "Mission Accomplished!!!";

        //设置画笔父类
        QPainter painter(this);

        //设置画笔颜色
        painter.setPen(QPen(Qt::red));

        //画出字句
        painter.drawText(rect(), Qt::AlignCenter, text);

        //结束
        return;
    }
    //设置画家
    QPainter painter(this);
    //画出背景
    QPixmap p1(":/image/levone_bg.png");
    //设置背景的大小
    painter.drawPixmap(0,0,1024,576,p1);
    //输出相关信息
    showInfo(&painter);

    foreach(TowerPosition *towerPos, m_towerPositionsList)
        towerPos->draw(&painter);
    foreach(Tower1 *tower, tower1_list)
        tower->draw(&painter);
    //循环遍历路径点的列表1
    foreach(WayPoint *wp, m_wayPointsList1)
        wp->draw(&painter);

    //循环遍历路径点的列表2
    foreach(WayPoint *wp, m_wayPointsList2)
        wp->draw(&painter);

    //循环遍历路径点的列表3
    foreach(WayPoint *wp, m_wayPointsList3)
        wp->draw(&painter);
    foreach(Target1 *enemy, target1_list)
        enemy->draw(&painter);
    foreach (Bullet *bullet, m_bulletList)
        bullet->draw(&painter);
    foreach (SelectionCircle * sel, m_selectioncircleList)
    {
        if(sel->showdisplay())
        {
            sel->draw(&painter);
        }
    }
    foreach (UandD * sel, m_uanddList)
    {
        if(sel->showdisplay() == 1)
        {
            sel->drawone(&painter);
        }
        if(sel->showdisplay() == 2)
        {
            sel->drawtwo(&painter);
        }
    }
    foreach(BoomTower * bt, m_boomtowerList)
    {
        bt->draw(&painter);
    }
    foreach(Explode * e, m_explodeList)
    {
        DrawExplosion(&painter, e->showpos(), e->showpicture());
        QTimer::singleShot(500, e , SLOT(deleteexplode()));
    }
}

void LevelOne::updateMap()
{

    //循环遍历敌人列表，让敌人移动
    foreach (Target1 *enemy, target1_list)
        enemy->move();

    //循环遍历塔列表，让塔攻击敌人
    foreach (Tower1 *tower, tower1_list)
        tower->checkEnemyInRange();

    foreach(BoomTower *bt, m_boomtowerList)
    {
        bt->checkEnemyInRange();
    }

    //更新界面
    update();
}

void LevelOne::triggerwave()
{

    //加载敌人
    loadWave();
}

void LevelOne::showInfo(QPainter *painter)
{

    //保存画笔
    painter->save();

    //设置画笔颜色
    painter->setPen(Qt::white);

    //画出需要输出的信息
    painter->drawText(QRect(385,10,2000,50),QString("源石 : %1    侵略 : %2    守卫建筑生命 : %3").arg(fee).arg(m_waves).arg(health));

    //还原画笔
    painter->restore();
}

void LevelOne::loadTowerPositions()
{

    //加载塔位置的全部18个点
    QPoint pos[] =
    {

        //左上
        QPoint(150,34),
        QPoint(225,34),
        QPoint(300,34),

        //中上
        QPoint(380,34),
        QPoint(455,34),
        QPoint(530,34),

        //右上
        QPoint(610,34),
        QPoint(685,34),
        QPoint(760,34),

        //左下
        QPoint(80,319),
        QPoint(170,319),
        QPoint(260,319),

        //中下
        QPoint(365,319),
        QPoint(455,319),
        QPoint(545,319),

        //右下
        QPoint(650,319),
        QPoint(740,319),
        QPoint(830,319),
    };

    //设置数组长度，即遍历次数
    int len	= sizeof(pos) / sizeof(pos[0]);

    //循环遍历输入进列表
    for (int i = 0; i < len; ++i)
    {
        TowerPosition * tp = new TowerPosition(pos[i], ":/image/shikuai.png");
        m_towerPositionsList.push_back(tp);
    }
}

void LevelOne::mousePressEvent(QMouseEvent *event)
{
    QPoint pressPos = event->pos();
    for(int i=0;i<m_selectioncircleList.size();i++)
    {
        if(m_selectioncircleList[i]->showdisplay())
        {
            if(!m_selectioncircleList[i]->contain(pressPos))
            {
                m_selectioncircleList[i]->resetdisplay();
            }
            if(m_selectioncircleList[i]->contain(pressPos))
            {
                m_selectioncircleList[i]->resetdisplay();
                if(m_selectioncircleList[i]->one(pressPos) && canBuyTower1())
                {
                    //设置随机数
                    int r = rand();
                    //随机播放其中之一的设置塔音效
                    if(r%2==0){
                        QMediaPlayer * player = new QMediaPlayer;
                        player->setMedia(QUrl("../big_res/amiya_set1.mp3"));
                        player->setVolume(60);
                        player->play();
                    }
                    else if(r%2!=0){
                        QMediaPlayer * player = new QMediaPlayer;
                        player->setMedia(QUrl("../big_res/amiya_set2.mp3"));
                        player->setVolume(60);
                        player->play();
                    }
                    m_selectioncircleList[i]->tp->settowerclass(1);
                    fee-=200;
                    QPoint centerpoint=m_selectioncircleList[i]->tp->centerPos();
                    Tower1_1 *tower1 = new Tower1_1(centerpoint,this,":/image/amiya.png",":/image/amiya_atk.png");
                    tower1->tp=m_selectioncircleList[i]->tp;
                    m_selectioncircleList[i]->tp->t=tower1;
                    tower1_list.push_back(tower1);
                }
                if(m_selectioncircleList[i]->two(pressPos) && canBuyTower2())
                {
                    //设置随机数
                    int r = rand();
                    //随机播放其中之一的设置塔音效
                    if(r%2==0){
                        QMediaPlayer * player = new QMediaPlayer;
                        player->setMedia(QUrl("../big_res/fmout_set1.mp3"));
                        player->setVolume(60);
                        player->play();
                    }
                    else if(r%2!=0){
                        QMediaPlayer * player = new QMediaPlayer;
                        player->setMedia(QUrl("../big_res/fmout_set2.mp3"));
                        player->setVolume(60);
                        player->play();
                    }
                    m_selectioncircleList[i]->tp->settowerclass(2);
                    //it->setHasTower();
                    fee-=300;
                    QPoint centerpoint=m_selectioncircleList[i]->tp->centerPos();
                    Tower1_2 *tower1 = new Tower1_2(centerpoint,this,":/image/fmout.png",":/image/fmout_atk.png");
                    tower1->tp=m_selectioncircleList[i]->tp;
                    m_selectioncircleList[i]->tp->t=tower1;
                    tower1_list.push_back(tower1);
                }
                if(m_selectioncircleList[i]->three(pressPos) && canBuyTower3())
                {
                    int r = rand();
                    if(r%2==0){
                        QMediaPlayer * player = new QMediaPlayer;
                        player->setMedia(QUrl("../big_res/plosis_set1.mp3"));
                        player->setVolume(60);
                        player->play();
                    }
                    else if(r%2!=0){
                        QMediaPlayer * player = new QMediaPlayer;
                        player->setMedia(QUrl("../big_res/plosis_set2.mp3"));
                        player->setVolume(60);
                        player->play();
                    }
                    m_selectioncircleList[i]->tp->settowerclass(3);
                    fee-=400;
                    QPoint centerpoint=m_selectioncircleList[i]->tp->centerPos();
                    Tower1_3 *tower1 = new Tower1_3(centerpoint,this,":/image/plosis.png");
                    tower1->tp=m_selectioncircleList[i]->tp;
                    m_selectioncircleList[i]->tp->bt=tower1;
                    m_boomtowerList.push_back(tower1);
                }
                if(m_selectioncircleList[i]->four(pressPos) && canBuyTower4())
                {
                    //设置随机数
                    int r = rand();
                    //随机播放其中之一的设置塔音效
                    if(r%2==0){
                        QMediaPlayer * player = new QMediaPlayer;
                        player->setMedia(QUrl("../big_res/ifrit_set1.mp3"));
                        player->setVolume(60);
                        player->play();
                    }
                    else if(r%2!=0){
                        QMediaPlayer * player = new QMediaPlayer;
                        player->setMedia(QUrl("../big_res/ifrit_set2.mp3"));
                        player->setVolume(60);
                        player->play();
                    }
                    m_selectioncircleList[i]->tp->settowerclass(4);
                    fee-=400;
                    QPoint centerpoint=m_selectioncircleList[i]->tp->centerPos();
                    Tower1_4 *tower1 = new Tower1_4(centerpoint,this,":/image/ifrit.png");
                    tower1->tp=m_selectioncircleList[i]->tp;
                    m_selectioncircleList[i]->tp->bt=tower1;
                    m_boomtowerList.push_back(tower1);
                }
            }
        }
    }
    for(int i=0;i<m_uanddList.size();i++)
    {
        if(m_uanddList[i]->showdisplay())
        {
            if(!m_uanddList[i]->contain(pressPos))
            {
                m_uanddList[i]->resetdisplay();
            }
            if(m_uanddList[i]->contain(pressPos))
            {
                m_uanddList[i]->resetdisplay();
                if(m_uanddList[i]->one(pressPos) && canBuyTower1())
                {
                    fee-=200;
                    if(m_uanddList[i]->tp->Towerclass() == 1 || m_uanddList[i]->tp->Towerclass() == 2 || m_uanddList[i]->tp->Towerclass() == 5 || m_uanddList[i]->tp->Towerclass() == 6)
                    {
                        removetower(m_uanddList[i]->tp->t);
                    }
                    if(m_uanddList[i]->tp->Towerclass() == 3 || m_uanddList[i]->tp->Towerclass() == 4)
                    {
                        removeboomtower(m_uanddList[i]->tp->bt);
                    }
                }
                if(m_uanddList[i]->three(pressPos) && canBuyTower2() && (m_uanddList[i]->tp->Towerclass()==1 || m_uanddList[i]->tp->Towerclass() == 2))
                {
                    if(m_uanddList[i]->tp->Towerclass() == 1)
                    {
                        fee-=300;
                        removetower(m_uanddList[i]->tp->t);
                        QPoint centerpoint=m_uanddList[i]->tp->centerPos();
                        Tower1_1upgrade *tower1 = new Tower1_1upgrade(centerpoint,this,":/image/amiya_p.png",":/image/amiya_atk.png");
                        tower1->tp=m_uanddList[i]->tp;
                        m_uanddList[i]->tp->t=tower1;
                        tower1_list.push_back(tower1);
                        m_uanddList[i]->tp->settowerclass(5);
                    }
                    if(m_uanddList[i]->tp->Towerclass() == 2)
                    {
                        fee-=300;
                        removetower(m_uanddList[i]->tp->t);
                        QPoint centerpoint=m_uanddList[i]->tp->centerPos();
                        Tower1_2upgrade *tower1 = new Tower1_2upgrade(centerpoint,this,":/image/fmout_p.png",":/image/fmout_atk.png");
                        tower1->tp=m_uanddList[i]->tp;
                        m_uanddList[i]->tp->t=tower1;
                        tower1_list.push_back(tower1);
                        m_uanddList[i]->tp->settowerclass(6);
                    }
                }
            }
        }
    }
    for(int i=0;i<m_towerPositionsList.size();i++)
    {
        TowerPosition * it = m_towerPositionsList[i];
        if (it->containPoint(pressPos) && !it->Towerclass())
        {
            it->cs->setdisplay();
            update();
            break;
        }
    }
    for(int i=0;i<m_towerPositionsList.size();i++)
    {
        TowerPosition * it = m_towerPositionsList[i];
        if (it->containPoint(pressPos) && it->Towerclass())
        {
            if(it->Towerclass()==1 || it->Towerclass()==2)
                it->uad->setdisplay(1);
            else
            {
                it->uad->setdisplay(2);
            }
            update();
            break;
        }
    }
    update();
}

bool LevelOne::canBuyTower1()
{
    if (fee >= 200)
        return true;
    return false;
}
bool LevelOne::canBuyTower2()
{
    if (fee >= 300)
        return true;
    return false;
}
bool LevelOne::canBuyTower3()
{
    if (fee >= 400)
        return true;
    return false;
}
bool LevelOne::canBuyTower4()
{
    if(fee >= 400)
        return true;
    return false;
}

void LevelOne::removetower(Tower1 *t)
{
    Q_ASSERT(t);
    if(t->targetenemy()!=0)
        t->targetenemy()->gotLostSight(t);
    t->setenemy(NULL);
    tower1_list.removeOne(t);
    t->tp->settowerclass(0);
    delete t;
}

void LevelOne::loadselectioncircle()
{
    foreach(TowerPosition * towerPos, m_towerPositionsList)
    {
        SelectionCircle * sel = new SelectionCircle(towerPos->centerPos(), ":/image/section.png");
        towerPos->cs=sel;
        sel->tp=towerPos;
        m_selectioncircleList.push_back(sel);
    }
}

void LevelOne::addWayPoints()
{

    //路径1
    WayPoint *wayPoint1 = new WayPoint(QPoint(100, 185));
    m_wayPointsList1.push_back(wayPoint1);

    WayPoint *wayPoint2 = new WayPoint(QPoint(900, 185));
    m_wayPointsList1.push_back(wayPoint2);
    wayPoint2->setNextWayPoint(wayPoint1);

    //路径2
    WayPoint *wayPoint3 = new WayPoint(QPoint(75, 260));
    m_wayPointsList2.push_back(wayPoint3);

    WayPoint *wayPoint4 = new WayPoint(QPoint(925, 260));
    m_wayPointsList2.push_back(wayPoint4);
    wayPoint4->setNextWayPoint(wayPoint3);

    //路径3
    WayPoint *wayPoint5 = new WayPoint(QPoint(50, 330));
    m_wayPointsList3.push_back(wayPoint5);

    WayPoint *wayPoint6 = new WayPoint(QPoint(950, 330));
    m_wayPointsList3.push_back(wayPoint6);
    wayPoint6->setNextWayPoint(wayPoint5);
}

void LevelOne::getHpDamage(int damage = 1)
{

    //生命值减去损害值
    health-=damage;

    //如果生命值小于等于0则游戏结束
    if (health == 0){

        QMediaPlayer * player = new QMediaPlayer;
        player->setMedia(QUrl("../big_res/b_ui_lose.wav"));
        player->setVolume(60);
        player->play();

        doGameOver();
    }

    return;
}

void LevelOne::removedEnemy(Target1 *enemy)
{

    //删除敌人
    Q_ASSERT(enemy);

    //从敌人列表中删除掉敌人
    target1_list.removeOne(enemy);

    //执行删除
    delete enemy;

    //如果敌人列表空
    if (target1_list.empty())
    {

        //敌人波数增加
        ++m_waves;

        //继续进行下一波敌人进攻
        if (!loadWave())
        {

            //如果没有下一波则任务完成
            m_gameWin = true;
        }
    }
}

bool LevelOne::loadWave()
{
    if (m_waves == 4)
    {
        QMediaPlayer * player = new QMediaPlayer();
        player->setMedia(QUrl("../big_res/b_ui_win.wav"));
        player->setVolume(60);
        player->play();
        return false;
    }
    if(m_waves == 1)
    {
        WayPoint *startWayPoint1 = m_wayPointsList1.back();
        WayPoint *startWayPoint2 = m_wayPointsList2.back();
        WayPoint *startWayPoint3 = m_wayPointsList3.back();
        int enemyStartInterval[] = { 1000,3000,5000,6000,7000,8000, 9000, 10000, 11000, 12000,13000,14000 };
        for (int i = 0; i < 12; ++i)
        {
            Target1_1 *enemy1 = new Target1_1(startWayPoint1, this, ":/image/target1.png");
            target1_list.push_back(enemy1);
            QTimer::singleShot(enemyStartInterval[i], enemy1, SLOT(doActivate()));

            Target1_1 *enemy2 = new Target1_1(startWayPoint2, this, ":/image/target2.png");
            target1_list.push_back(enemy2);
            QTimer::singleShot(enemyStartInterval[i], enemy2, SLOT(doActivate()));

            Target1_1 *enemy3 = new Target1_1(startWayPoint3, this, ":/image/target1.png");
            target1_list.push_back(enemy3);
            QTimer::singleShot(enemyStartInterval[i], enemy3, SLOT(doActivate()));
        }
        return true;
    }
    if(m_waves == 2)
    {
        WayPoint *startWayPoint1 = m_wayPointsList1.back(); // 这里是个逆序的，尾部才是其实节点
        WayPoint *startWayPoint2 = m_wayPointsList2.back();
        WayPoint *startWayPoint3 = m_wayPointsList3.back();
        int enemyStartInterval[] = { 1000,3000,5000,6000,7000,8000 };
        for (int i = 0; i < 4; ++i)
        {
            Target1_1 *enemy1 = new Target1_1(startWayPoint1, this, ":/image/target1.png");
            target1_list.push_back(enemy1);
            QTimer::singleShot(enemyStartInterval[i], enemy1, SLOT(doActivate()));

            Target1_1 *enemy2 = new Target1_1(startWayPoint2, this, ":/image/target3.png");
            target1_list.push_back(enemy2);
            QTimer::singleShot(enemyStartInterval[i], enemy2, SLOT(doActivate()));

            Target1_1 *enemy3 = new Target1_1(startWayPoint3, this, ":/image/target1.png");
            target1_list.push_back(enemy3);
            QTimer::singleShot(enemyStartInterval[i], enemy3, SLOT(doActivate()));
        }
        for (int i = 4; i < 6; ++i)
        {
            Target1_2 *enemy1 = new Target1_2(startWayPoint1, this, ":/image/target3.png");
            target1_list.push_back(enemy1);
            QTimer::singleShot(enemyStartInterval[i], enemy1, SLOT(doActivate()));

            Target1_2 *enemy2 = new Target1_2(startWayPoint2, this, ":/image/target4.png");
            target1_list.push_back(enemy2);
            QTimer::singleShot(enemyStartInterval[i], enemy2, SLOT(doActivate()));

            Target1_2 *enemy3 = new Target1_2(startWayPoint3, this, ":/image/target3.png");
            target1_list.push_back(enemy3);
            QTimer::singleShot(enemyStartInterval[i], enemy3, SLOT(doActivate()));
        }
        return true;
    }
    if(m_waves == 3)
    {
        WayPoint *startWayPoint1 = m_wayPointsList1.back(); // 这里是个逆序的，尾部才是其实节点
        WayPoint *startWayPoint2 = m_wayPointsList2.back();
        WayPoint *startWayPoint3 = m_wayPointsList3.back();
        int enemyStartInterval[] = { 1000,3000,5000,6000,7000,8000 };
        for (int i = 0; i < 6; ++i)
        {
            Target1_2 *enemy1 = new Target1_2(startWayPoint1, this, ":/image/target2.png");
            target1_list.push_back(enemy1);
            QTimer::singleShot(enemyStartInterval[i], enemy1, SLOT(doActivate()));

            Target1_2 *enemy2 = new Target1_2(startWayPoint2, this, ":/image/target3.png");
            target1_list.push_back(enemy2);
            QTimer::singleShot(enemyStartInterval[i], enemy2, SLOT(doActivate()));

            Target1_2 *enemy3 = new Target1_2(startWayPoint3, this, ":/image/target4.png");
            target1_list.push_back(enemy3);
            QTimer::singleShot(enemyStartInterval[i], enemy3, SLOT(doActivate()));
        }
        return true;
    }
}

void LevelOne::addBullet(Bullet *bullet)
{

    Q_ASSERT(bullet);

    //将子弹添加到列表中
    m_bulletList.push_back(bullet);
}

void LevelOne::removedBullet(Bullet *bullet)
{

    Q_ASSERT(bullet);

    //将子弹从列表中移除
    m_bulletList.removeOne(bullet);

    //删除子弹
    delete bullet;
}

void LevelOne::awardgold(int gold)
{

    //源石加上奖励金
    fee+=gold;
}

QList<Target1 *> LevelOne::enemyList() const
{

    //返回敌人1列表
    return target1_list;
}

void LevelOne::doGameOver()
{

    //结束游戏
    m_gameEnd=true;
}

void LevelOne::removeexplode(Explode *e)
{
    m_explodeList.removeOne(e);
}

void LevelOne::removeboomtower(BoomTower *bt)
{
    Q_ASSERT(bt);
    m_boomtowerList.removeOne(bt);
    bt->tp->settowerclass(0);
    delete bt;
}

void LevelOne::addexplode(QPoint p, QString filename)
{
    Explode * e = new Explode (p, this, filename);
    m_explodeList.push_back(e);
}

void LevelOne::loaduandd()
{
    foreach(TowerPosition * towerPos, m_towerPositionsList)
    {
        UandD * sel = new UandD(towerPos->centerPos(),":/image/section.png",":/image/section.png");
        towerPos->uad=sel;
        sel->tp=towerPos;
        m_uanddList.push_back(sel);
    }
}

void LevelOne::DrawExplosion(QPainter * painter, QPoint coor, QString filename)
{
    painter->drawPixmap(coor.x()-50,coor.y()-80, 100, 100, QPixmap(QString(filename)));
}

