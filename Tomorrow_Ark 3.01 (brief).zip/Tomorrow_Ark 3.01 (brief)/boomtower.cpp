#include "boomtower.h"
#include "levelone.h"
#include "target1.h"
#include "utility.h"
#include <QPainter>

BoomTower::BoomTower(QPoint pos, LevelOne *game,QString pixfilename): QObject (0)
{
    mgame=game;
    QPixmap p(pixfilename);
    QSize q(p.width(),p.height());
    this->pos=pos;
    this->pixmap=p;
    this->ms_fixedSize=q;
    this->triggerrange=150;
    this->damagerange=400;
}

void BoomTower::draw(QPainter *painter)
{
    painter->save();
    painter->setPen(Qt::blue);
    painter->drawEllipse(pos, triggerrange, triggerrange);
    painter->setPen(Qt::red);
    painter->drawEllipse(pos, damagerange, damagerange);
    QPixmap sprite(":/pictures/pictures/yzy.jpg");
    static const QPoint offsetPoint(-sprite.width()/2,-sprite.height()/2);
    painter->translate(pos);
    painter->drawPixmap(offsetPoint, pixmap);
    painter->restore();
}

void BoomTower::checkEnemyInRange()
{
    QList<Target1 *> enemyList = mgame->enemyList();
    foreach (Target1 *enemy, enemyList)
    {
        if (crash(pos,triggerrange, enemy->pos(), 1))
        {
            this->explode();
            break;
        }
    }
}
void BoomTower::explode()
{

}
QPoint BoomTower::showcenterpos()
{
    return pos;
}
