#include "target1_2.h"

Target1_2::Target1_2(WayPoint *startWayPoint, LevelOne *game, QString filename): Target1 (startWayPoint, game)
{
    QPixmap p(filename);
    m_sprite=p;
    ms_fixedSize=QSize(m_sprite.width(),m_sprite.height());
    m_maxHp=150;
    m_currentHp=150;
    m_walkingSpeed=1.0;
    awardgold=400;
}
double Target1_2::showmaxhp()
{
    return this->m_maxHp;
}

double Target1_2::showcurrenthp()
{
    return this->m_currentHp;
}

double Target1_2::showwalkingspeed()
{
    return this->m_walkingSpeed;
}

int Target1_2::showawardgold()
{
    return this->awardgold;
}

void Target1_2::setcurrenthp(double newhp)
{
    this->m_currentHp=newhp;
}

QSize Target1_2::showsize()
{
    return this->ms_fixedSize;
}

QPixmap Target1_2::showpixmap()
{
    return this->m_sprite;
}
void Target1_2::setwalkingspeed(double newspeed)
{
    this->m_walkingSpeed=newspeed;
}
