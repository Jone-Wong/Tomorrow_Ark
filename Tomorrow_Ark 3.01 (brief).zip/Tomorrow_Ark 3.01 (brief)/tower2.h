#ifndef TOWER2_H
#define TOWER2_H


#include <QObject>
#include "tower1.h"

class Tower2 : public Tower1
{
public:
    Tower2(QPoint _pos, LevelOne *game , QString pixfilename, QString b);
    virtual int showdamage();
    virtual int showfirerange();
    virtual int showfirerate();
    virtual QString showbullet();
private:
    int firerange;
    int damage;
    int firerate;
    QString bullet;
};

#endif // TOWER2_H
