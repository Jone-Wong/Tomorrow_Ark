#include "target1_1.h"

Target1_1::Target1_1(WayPoint *startWayPoint, LevelOne *game, QString filename): Target1 (startWayPoint, game)
{
    QPixmap p(filename);
    m_sprite=p;
    ms_fixedSize=QSize(m_sprite.width(),m_sprite.height());
    m_maxHp=40;
    m_currentHp=40;
    m_walkingSpeed=2.0;
    awardgold=200;
}
double Target1_1::showmaxhp()
{
    return this->m_maxHp;
}

double Target1_1::showcurrenthp()
{
    return this->m_currentHp;
}

double Target1_1::showwalkingspeed()
{
    return this->m_walkingSpeed;
}

int Target1_1::showawardgold()
{
    return this->awardgold;
}

void Target1_1::setcurrenthp(double newhp)
{
    this->m_currentHp=newhp;
}

QSize Target1_1::showsize()
{
    return this->ms_fixedSize;
}

QPixmap Target1_1::showpixmap()
{
    return this->m_sprite;
}
void Target1_1::setwalkingspeed(double newspeed)
{
    this->m_walkingSpeed=newspeed;
}
