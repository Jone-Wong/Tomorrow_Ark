#include "explode.h"
#include "levelone.h"

Explode::Explode(QPoint pos, LevelOne * game, QString filename):QObject (0)
{

    //对各变量进行初始化
    mpos=pos;
    m_game=game;
    this->filename=filename;
}

QPoint Explode::showpos()
{

    //返回位置
    return this->mpos;
}

void Explode::deleteexplode()
{

    //删除
    m_game->removeexplode(this);
    delete this;
}

QString Explode::showpicture()
{

    //返回文件名字
    return this->filename;
}
