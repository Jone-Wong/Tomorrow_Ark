#ifndef BULLET_H
#define BULLET_H

#include <QObject>
#include <QPoint>
#include <QSize>
#include <QPixmap>

class QPainter;
class Target1;
class LevelOne;

class Bullet : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QPoint m_currentPos READ currentPos WRITE setCurrentPos)
public:
    Bullet(QPoint startPos, QPoint targetPoint, int damage, Target1 *target,
           LevelOne *game, QString filename);

    void draw(QPainter *painter);
    void move();
    void setCurrentPos(QPoint pos);
    QPoint currentPos();

private slots:
    void hitTarget();

private:
    QPoint	m_startPos;
    QPoint	m_targetPos;
    QPixmap	m_sprite;
    QPoint	m_currentPos;
    Target1 *	m_target;
    LevelOne *	m_game;
    int	m_damage;
    QSize ms_fixedSize;

};

#endif // BULLET_H
