#ifndef TOWERPOSITION_H
#define TOWERPOSITION_H

#include <QObject>
#include <QPoint>
#include <QPixmap>
#include "uandd.h"

class SelectionCircle;
class Tower1;
class BoomTower;
class UandD;

class TowerPosition
{
public:
    TowerPosition(QPoint pos, QString filename);
    void settowerclass(int towerclass);
    int Towerclass();
    QPoint centerPos();
    bool containPoint(QPoint &pos);
    void draw(QPainter *painter);
    SelectionCircle * cs;
    UandD * uad;
    Tower1 * t;
    BoomTower * bt;

private:
    QPoint		m_pos;
    int		m_Towerclass;
    QPixmap		m_sprite;
    QSize ms_fixedSize;

signals:

};

#endif // TOWERPOSITION_H
