#ifndef TOWER1_H
#define TOWER1_H

#include <QObject>
#include <QPoint>
#include <QPixmap>
#include "bullet.h"

class Target1;
class LevelOne;
class Bullet;
class TowerPosition;

class Tower1 : QObject
{
    Q_OBJECT
public:
    Tower1(QPoint pos, LevelOne *game,QString pixfilename);
    void draw(QPainter * painter);
    void targetKilled();
    void attackEnemy();
    void chooseEnemyForAttack(Target1 * enemy);
    void lostSightOfEnemy();
    void checkEnemyInRange();
    virtual int showdamage();
    virtual int showfirerange();
    virtual int showfirerate();
    virtual QString showbullet();
    void setenemy(Target1 * e);
    Target1 * targetenemy();
    TowerPosition * tp;
public slots:
    void shootWeapon();
protected:
    QPoint pos;
    bool mattacking;
    QSize ms_fixedSize;
    QPixmap pixmap;
    int firerange;
    int damage;
    int firerate;
    QString bullet;
    double mrotationpixmap;
    Target1 * mchooseEnemy;
    QTimer * mfireRateTimer;
    LevelOne * mgame;
signals:
};

#endif // TOWER1_H
