#include "uandd.h"

UandD::UandD(QPoint mpos, QString filename1, QString filename2) : QObject(0)
{
    this->pos=mpos;
    QPixmap p(filename1);
    size=QSize(p.width(),p.height());
    pixmap1=p;
    QPixmap q(filename2);
    pixmap2=q;
    display=0;
}
void UandD::drawone(QPainter *painter)
{
    painter -> drawPixmap(pos.x()-size.width()/2,pos.y()-size.height()/2,pixmap1);
}
void UandD::drawtwo(QPainter *painter)
{
    painter -> drawPixmap(pos.x()-size.width()/2,pos.y()-size.height()/2,pixmap2);
}
int UandD::showdisplay()
{
    return this->display;
}
void UandD::setdisplay(int towerclass)
{
    this->display=towerclass;
}
void UandD::resetdisplay()
{
    this->display=0;
}
bool UandD::contain(QPoint pos)
{
    return one(pos)||two(pos)||three(pos)||four(pos);
}
bool UandD::one(QPoint pos)
{
    bool isXInHere = this->pos.x() + 16 < pos.x() && pos.x() < (this->pos.x() + 32);
    bool isYInHere = this->pos.y() - 16 < pos.y() && pos.y() < (this->pos.y() + 16);
    return isXInHere && isYInHere;
}
bool UandD::two(QPoint pos)
{
    bool isXInHere = this->pos.x() - 16 < pos.x() && pos.x() < (this->pos.x() + 16);
    bool isYInHere = this->pos.y() + 16 < pos.y() && pos.y() < (this->pos.y() + 32);
    return isXInHere && isYInHere;
}
bool UandD::three(QPoint pos)
{
    bool isXInHere = this->pos.x() - 32 < pos.x() && pos.x() < (this->pos.x() - 16);
    bool isYInHere = this->pos.y() - 16 < pos.y() && pos.y() < (this->pos.y() + 16);
    return isXInHere && isYInHere;
}
bool UandD::four(QPoint pos)
{
    bool isXInHere = this->pos.x() - 16 < pos.x() && pos.x() < (this->pos.x() + 16);
    bool isYInHere = this->pos.y() - 32 < pos.y() && pos.y() < (this->pos.y() - 16);
    return isXInHere && isYInHere;
}
