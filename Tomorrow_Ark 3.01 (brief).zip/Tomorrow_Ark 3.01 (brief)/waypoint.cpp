#include "waypoint.h"

WayPoint::WayPoint(QPoint pos)
    : m_pos(pos)
    , m_nextWayPoint(NULL)
{
}

void WayPoint::setNextWayPoint(WayPoint *nextPoint)
{

    //下一个路径点
    m_nextWayPoint = nextPoint;
}

WayPoint* WayPoint::nextWayPoint() const
{

    //返回下一个路径点
    return m_nextWayPoint;
}

const QPoint WayPoint::pos() const
{

    //返回位置
    return m_pos;
}

void WayPoint::draw(QPainter *painter) const
{

    //保存画笔
    painter->save();

    //设置白色
    painter->setPen(Qt::black);

    //设置大圈、小圈
    painter->drawEllipse(m_pos, 6, 6);
    painter->drawEllipse(m_pos, 2, 2);

    if (m_nextWayPoint)
        painter->drawLine(m_pos, m_nextWayPoint->m_pos);

    //返回储存
    painter->restore();
}

