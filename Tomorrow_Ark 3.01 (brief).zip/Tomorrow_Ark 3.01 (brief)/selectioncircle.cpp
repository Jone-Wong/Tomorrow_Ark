#include "selectioncircle.h"
SelectionCircle::SelectionCircle(QPoint mpos, QString filename) : QObject(0)
{
    this->pos=mpos;
    QPixmap p(filename);
    size=QSize(p.width(),p.height());
    pixmap=p;
    display=0;
}
void SelectionCircle::draw(QPainter *painter)
{
    painter -> drawPixmap(pos.x()-size.width()/2,pos.y()-size.height()/2,pixmap);
}
bool SelectionCircle::showdisplay()
{
    return this->display;
}
void SelectionCircle::setdisplay()
{
    this->display=1;
}
void SelectionCircle::resetdisplay()
{
    this->display=0;
}
bool SelectionCircle::contain(QPoint pos)
{
    return one(pos)||two(pos)||three(pos)||four(pos);
}
bool SelectionCircle::one(QPoint pos)
{
    bool isXInHere = this->pos.x() +16 < pos.x() && pos.x() < (this->pos.x() + 32);
    bool isYInHere = this->pos.y() - 16 < pos.y() && pos.y() < (this->pos.y() + 16);
    return isXInHere && isYInHere;
}
bool SelectionCircle::two(QPoint pos)
{
    bool isXInHere = this->pos.x() - 16 < pos.x() && pos.x() < (this->pos.x() + 16);
    bool isYInHere = this->pos.y() + 16 < pos.y() && pos.y() < (this->pos.y() + 32);
    return isXInHere && isYInHere;
}
bool SelectionCircle::three(QPoint pos)
{
    bool isXInHere = this->pos.x() - 32 < pos.x() && pos.x() < (this->pos.x() - 16);
    bool isYInHere = this->pos.y() - 16 < pos.y() && pos.y() < (this->pos.y() + 16);
    return isXInHere && isYInHere;
}
bool SelectionCircle::four(QPoint pos)
{
    bool isXInHere = this->pos.x() - 16 < pos.x() && pos.x() < (this->pos.x() + 16);
    bool isYInHere = this->pos.y() - 32 < pos.y() && pos.y() < (this->pos.y() - 16);
    return isXInHere && isYInHere;
}

