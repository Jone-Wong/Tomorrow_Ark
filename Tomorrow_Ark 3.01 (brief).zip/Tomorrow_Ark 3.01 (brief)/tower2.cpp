#include "tower2.h"
#include "tower1.h"

Tower2::Tower2(QPoint _pos, LevelOne *game ,QString pixfilename, QString b): Tower1 (_pos, game, pixfilename)
{
    firerange=300;
    firerate=2000;
    damage=100;
    bullet=b;
}

int Tower2::showdamage()
{
    return this->damage;
}

int Tower2::showfirerate()
{
    return this->firerate;
}

int Tower2::showfirerange()
{
    return this->firerange;
}

QString Tower2::showbullet()
{
    return this->bullet;
}
