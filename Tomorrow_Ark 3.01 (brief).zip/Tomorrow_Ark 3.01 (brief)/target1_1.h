#ifndef TARGET1_1_H
#define TARGET1_1_H

#include <QWidget>
#include <QObject>
#include "target1.h"
class Target1_1 : public Target1
{
public:
    Target1_1(WayPoint *startWayPoint, LevelOne *game, QString filename);
    virtual double showmaxhp();
    virtual double showcurrenthp();
    virtual double showwalkingspeed();
    virtual int showawardgold();
    virtual void setcurrenthp(double newhp);
    virtual void setwalkingspeed(double newspeed);
    virtual QPixmap showpixmap();
    virtual QSize showsize();
private:
    double				m_maxHp;
    double				m_currentHp;
    double			m_walkingSpeed;
    int awardgold;
    QPixmap	m_sprite;
    QSize ms_fixedSize;
signals:
public slots:
};
#endif // TARGET1_1_H
