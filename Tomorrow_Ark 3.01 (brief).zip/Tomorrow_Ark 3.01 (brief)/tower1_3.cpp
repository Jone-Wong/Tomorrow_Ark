#include "tower1_3.h"
#include "levelone.h"
#include "target1.h"
#include "utility.h"
#include <QPainter>
#include <QMediaPlayer>

Tower1_3::Tower1_3(QPoint pos, LevelOne *game,QString pixfilename): BoomTower (pos, game, pixfilename)
{
    this->damage=20;
}
void Tower1_3::explode()
{
    QList<Target1 *> enemyList = mgame->enemyList();
    foreach (Target1 *enemy, enemyList)
    {
        if (crash(pos,damagerange, enemy->pos(), 1))
        {
            QMediaPlayer * player = new QMediaPlayer;
            player->setMedia(QUrl("../big_res/plosis_exp.mp3"));
            player->setVolume(100);
            player->play();
            enemy->getDamage(damage);
        }
    }
    mgame->removeboomtower(this);
    mgame->addexplode(pos, ":/image/ExplosionEffect6.png");
}
