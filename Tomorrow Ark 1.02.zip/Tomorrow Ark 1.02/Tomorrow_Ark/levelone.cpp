#include "levelone.h"
#include <QPainter>
#include "settvr_button.h"
#include <QTimer>


LevelOne::LevelOne(QWidget *parent) : QMainWindow(parent)
{
    //设置图片大小
    this->setFixedSize(1024,576);

    //设置创建_塔1-阿米娅_的按钮
    Settvr_Button * setTower1 = new Settvr_Button(":/image/settower_button.png");

    //设置按钮的父类、位置
    setTower1->setParent(this);
    setTower1->move(225,40);

    //点击按钮
    connect(setTower1,&QPushButton::clicked,this,[=](){

        //按钮跳动
        setTower1->zoomdown();
        setTower1->zoomup();

        //添加_塔1-阿米娅_和_敌人1-小车_
        LevelOne::addTarget();
        LevelOne::set_tower1();

//        connect(setTower1,&Settvr_Button::clicked,this,&LevelOne::addTarget);
//        connect(setTower1,&Settvr_Button::clicked,this,&LevelOne::set_tower1);

    });

    //计时，并定时刷新界面，保证流畅性
    QTimer * timer = new QTimer (this);
    connect (timer, &QTimer::timeout, this, &LevelOne::updateScence);
    timer->start(10);
}

void LevelOne::paintEvent(QPaintEvent*){

    //选择关卡界面
    QPainter painter(this);

    //导入选择关卡界面图片
    QPixmap pixmap(":/image/levone_bg.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);

    //循环遍历形成动画
    foreach(Tower1 * tower, tower1_list){
        tower -> draw(&painter);
    }

    //循环遍历形成动画
    foreach(Target1 * target, target1_list){
        target -> draw(&painter);
    }

}

void LevelOne::set_tower1(){

    //创建_塔1-阿米娅_，设置位置以及图像
    Tower1 * a_new_tower = new Tower1(QPoint (230,30),":/image/tower1.png");

    //存入list中
    tower1_list.push_back(a_new_tower);

    //刷新
    update();
}

void LevelOne::addTarget(){

    //创建_敌人1-小车_，设置位置以及图像
    Target1 * target = new Target1(QPoint (900,110), QPoint(0,110), ":/image/target1.png");

    //存入list中
    target1_list.push_back(target);

    //让敌人1移动
    target->move();

    //刷新
    update();
}

void LevelOne::updateScence(){

    //刷新
    update();
}
