#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMainWindow>
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>
#include <QTimer>
#include "s2c_button.h"
#include "chooselevel.h"
#include "levone_button.h"
#include "levelone.h"
#include "settvr_button.h"
#include "story.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    //设置游戏界面窗口大小
    this->setFixedSize(1024,576);
    ui->setupUi(this);

    //设置一个按钮
    S2C_Button * btn = new S2C_Button(":/image/button.png");

    S2C_Button * sbtn = new S2C_Button(":/image/stry_button.png");

    //设置按钮的父类和位置
    btn->setParent(this);
    btn->move(445,375);

    sbtn -> setParent(this);
    sbtn -> move(930,400);

    //创建选择关卡页面
    ChooseLevel * scene = new ChooseLevel;
    Story * exp = new Story;

    //设置按钮弹跳效果
    connect(btn,&QPushButton::clicked,this,[=](){

        //弹跳效果
        btn->zoomdown();
        btn->zoomup();

        //设置时间间隔
        QTimer::singleShot(300,this,[=](){

            //界面的隐藏和显现
            this->hide();
            scene->show();
        });
    });

    connect(sbtn, &QPushButton::clicked,this,[=](){
        sbtn -> zoomdown();
        sbtn -> zoomup();

        QTimer::singleShot(300,this,[=](){

            this->hide();
            exp->show();
        });
    });

    //由选择关卡界面返回主界面按钮
    connect(scene,&ChooseLevel::chooseBack,this,[=](){

        //界面的隐藏和显现
        scene->hide();
        this->show();
    });

    //由选择关卡界面返回主界面按钮
    connect(exp,&Story::chooseBack,this,[=](){

        //界面的隐藏和显现
        exp->hide();
        this->show();
    });

    //导入第一关按钮图像
    Levone_Button * lvonebtn = new Levone_Button(":/image/level_one.png");

    //设置第一关按钮父类和位置
    lvonebtn->setParent(scene);
    lvonebtn->move(80,100);

    //设置第一关背景
    LevelOne * levone = new LevelOne;

    connect(lvonebtn,&QPushButton::clicked,this,[=](){

        //第一关按钮弹跳效果
        lvonebtn->zoomdown();
        lvonebtn->zoomup();

        //设置时间间隔
        QTimer::singleShot(300,this,[=](){

            //画面的隐藏与显现
            this->hide();
            levone->show();
        });
    });

}

void MainWindow::paintEvent(QPaintEvent *){

    //主界面
    QPainter painter(this);

    //导入主界面背景
    QPixmap pixmap(":/image/start.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);

    showInfo(&painter);
}

void MainWindow::showInfo(QPainter * painter){

    painter -> save();

    painter -> setPen(Qt::white);
    painter -> drawText(QRect(340,540,500,100),QString("Copy Right @ Wang Kaixin , June 5 , 2020  _Version 1.02_"));

    painter -> restore();
}

MainWindow::~MainWindow()
{
    delete ui;
}
