#ifndef TARGET1_H
#define TARGET1_H

#include <QObject>
#include <QPropertyAnimation>
#include <QPoint>
#include <QPixmap>
#include <QPainter>

class Target1 : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QPoint currentPos READ getCurrentPos WRITE setCurrentPos)
public:
    Target1(QPoint startPos, QPoint endPos, QString fileName);

    void draw(QPainter * painter);
    void move();

    QPoint getCurrentPos();
    void setCurrentPos(QPoint Pos);
private:
    QPoint startPos;
    QPoint endPos;
    QPoint currentPos;
    QPixmap pixmap;
signals:

};

#endif // TARGET1_H
