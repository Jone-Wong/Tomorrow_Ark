#ifndef SETTVR_BUTTON_H
#define SETTVR_BUTTON_H

#include <QWidget>
#include <QPushButton>

class Settvr_Button : public QPushButton
{
    Q_OBJECT
public:
    Settvr_Button(QString pix);
    void zoomup();
    void zoomdown();


signals:

};

#endif // SETTVR_BUTTON_H
