#include "tower1_1upgrade.h"

Tower1_1upgrade::Tower1_1upgrade(QPoint _pos, LevelOne *game ,QString pixfilename, QString b): Tower1 (_pos, game, pixfilename)
{
    firerange=150;
    firerate=400;
    damage=15;
    bullet = b;
}

int Tower1_1upgrade::showdamage()
{
    return this->damage;
}
int Tower1_1upgrade::showfirerate()
{
    return this->firerate;
}
int Tower1_1upgrade::showfirerange()
{
    return this->firerange;
}
QString Tower1_1upgrade::showbullet()
{
    return this->bullet;
}
