#include "tower1_2.h"

Tower1_2::Tower1_2(QPoint _pos, LevelOne *game ,QString pixfilename, QString b): Tower1(_pos, game, pixfilename)
{
    firerange=300;
    firerate=2000;
    damage=100;
    bullet=b;
}

int Tower1_2::showdamage()
{
    return this->damage;
}
int Tower1_2::showfirerate()
{
    return this->firerate;
}
int Tower1_2::showfirerange()
{
    return this->firerange;
}
QString Tower1_2::showbullet()
{
    return this->bullet;
}
