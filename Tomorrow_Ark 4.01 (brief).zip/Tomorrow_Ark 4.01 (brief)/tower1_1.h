#ifndef TOWER1_1_H
#define TOWER1_1_H

#include "tower1.h"
#include <QObject>


class Tower1_1 : public Tower1
{
public:
    Tower1_1(QPoint _pos,LevelOne *game ,QString pixfilename, QString b);
    virtual int showdamage();
    virtual int showfirerange();
    virtual int showfirerate();
    virtual QString showbullet();
private:
    int firerange;
    int damage;
    int firerate;
    QString bullet;
};

#endif // TOWER1_1_H
