#ifndef SELECTIONCIRCLE_H
#define SELECTIONCIRCLE_H

#include <QPixmap>
#include <QObject>
#include <QPainter>

class TowerPosition;
class TowerPosition_2;

class SelectionCircle : public QObject
{
    Q_OBJECT
public:
    SelectionCircle(QPoint mpos, QString filename);
    void draw(QPainter *painter);
    bool showdisplay();
    void setdisplay();
    void resetdisplay();
    bool contain(QPoint cp);
    bool one(QPoint);
    bool two(QPoint);
    bool three(QPoint);
    bool four(QPoint);
    TowerPosition * tp;

private:
    QPixmap pixmap;
    QPoint pos;
    QSize size;
    bool display;

signals:

public slots:

};


class SelectionCircle_2 : public QObject
{
    Q_OBJECT
public:
    SelectionCircle_2(QPoint mpos, QString filename);
    void draw(QPainter *painter);
    bool showdisplay();
    void setdisplay();
    void resetdisplay();
    bool contain(QPoint cp);
    bool one(QPoint);
    bool two(QPoint);
    bool three(QPoint);
    bool four(QPoint);
    TowerPosition_2 * tp;

private:
    QPixmap pixmap;
    QPoint pos;
    QSize size;
    bool display;

signals:

public slots:

};
#endif // SELECTIONCIRCLE_H
