#ifndef TOWER1_1UPGRADE_H
#define TOWER1_1UPGRADE_H

#include <QObject>
#include "tower1.h"
class Tower1_1upgrade : public Tower1
{
public:
    Tower1_1upgrade(QPoint _pos, LevelOne *game ,QString pixfilename, QString b);
    virtual int showdamage();
    virtual int showfirerange();
    virtual int showfirerate();
    virtual QString showbullet();
private:
    int firerange;
    int damage;
    int firerate;
    QString bullet;
   // Enemy * mchooseEnemy;
};

#endif // TOWER1_1UPGRADE_H
