#include "tower2_3.h"
#include "leveltwo.h"
#include "target2.h"
#include "utility.h"
#include <QPainter>
#include <QMediaPlayer>

Tower2_3::Tower2_3(QPoint pos, LevelTwo *game,QString pixfilename): BoomTower_2 (pos, game, pixfilename)
{
    this->damage=20;
}
void Tower2_3::explode()
{
    QList<Target2 *> enemyList = mgame->enemyList();
    foreach (Target2 *enemy, enemyList)
    {
        if (crash(pos,damagerange, enemy->pos(), 1))
        {
            QMediaPlayer * player = new QMediaPlayer;
            player->setMedia(QUrl("../big_res/plosis_exp.mp3"));
            player->setVolume(100);
            player->play();
            enemy->getDamage(damage);
        }
    }
    mgame->removeboomtower(this);
    mgame->addexplode(pos, ":/image/ExplosionEffect6.png");
}
