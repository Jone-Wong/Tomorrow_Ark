#ifndef LEVELTWO_H
#define LEVELTWO_H

#include <QMainWindow>
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QList>
#include "target2.h"
#include "towerposition.h"
#include "tower2.h"
#include "selectioncircle.h"
#include "explode.h"
#include "boomtower.h"
#include "uandd.h"

class Target2;
class WayPoint;
class Bullet_2;
class Settvr_Button;
class Explode_2;
class SelectionCircle_2;
class Tower1_3;
class BoomTower_2;
class TowerPosition_2;
class UandD_2;


class LevelTwo : public QMainWindow
{
    Q_OBJECT
public:
   explicit LevelTwo(QWidget *parent = nullptr);
   void paintEvent(QPaintEvent*);
   void showInfo(QPainter *);
   void loadTowerPositions();
   void addWayPoints();
   void getHpDamage(int damage/* = 1*/);
   void mousePressEvent(QMouseEvent *event);
   bool canBuyTower1();
   bool canBuyTower2();
   bool canBuyTower3();
   bool canBuyTower4();
   void removedEnemy(Target2 *enemy);
   bool loadWave();
   void addBullet(Bullet_2 * b);
   QList<Target2 *> enemyList() const;
   void removedBullet(Bullet_2 *bullet);
   void removeboomtower(BoomTower_2 *bt);
   void removetower(Tower2 *t);
   void awardgold(int gold);
   void doGameOver();
   void loadselectioncircle();
   void DrawExplosion(QPainter * painter, QPoint coor, QString filename);
   void addexplode(QPoint p, QString filename);
   void removeexplode(Explode_2 * e);
   void loaduandd();


public slots:
   void updateMap();
   void triggerwave();

private:
   int fee = 10000;
   int m_waves = 1;
   int health = 5;
   bool m_gameWin = false;
   bool m_gameEnd = false;
   QList<Tower2 *> tower1_list;
   QList<Target2 *> target1_list;
   QList<TowerPosition_2 *> m_towerPositionsList;
   QList<WayPoint *> m_wayPointsList1;
   QList<WayPoint *> m_wayPointsList2;
   QList<WayPoint *> m_wayPointsList3;
   QList<WayPoint *> m_wayPointsList4;
   QList<Bullet_2 *>	m_bulletList;
   QList<SelectionCircle_2 *> m_selectioncircleList;
   QList<BoomTower_2 *> m_boomtowerList;
   QList<Explode_2 *> m_explodeList;
   QList<UandD_2 *> m_uanddList;

signals:
    void chooseBack();

};


#endif // LEVELTWO_H
