#include "tower1_1.h"
Tower1_1::Tower1_1(QPoint _pos, LevelOne *game ,QString pixfilename, QString b): Tower1 (_pos, game, pixfilename)
{
    firerange=150;
    firerate=400;
    damage=10;
    bullet = b;
}

int Tower1_1::showdamage()
{
    return this->damage;
}
int Tower1_1::showfirerate()
{
    return this->firerate;
}
int Tower1_1::showfirerange()
{
    return this->firerange;
}
QString Tower1_1::showbullet()
{
    return this->bullet;
}
