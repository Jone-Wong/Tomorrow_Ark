#include "tower1.h"
#include <QPoint>
#include <QPixmap>
#include <QPainter>
#include <QTimer>
#include <QtMath>
#include <QMediaPlayer>
#include "target1.h"
#include "levelone.h"
#include "utility.h"
#include "bullet.h"

Tower1::Tower1(QPoint _pos, LevelOne *game ,QString pixfilename):mgame(game)
{
    this->pos=_pos;
    QPixmap p1(pixfilename);
    ms_fixedSize=QSize(p1.width(),p1.height());
    this->pixmap=p1;
//    firerange=150;
//    firerate=400;
//    damage=10;
    mattacking=false;
    mrotationpixmap=0.0;
    mchooseEnemy=NULL;
    mfireRateTimer = new QTimer(this);
    connect(mfireRateTimer,SIGNAL(timeout()),SLOT(shootWeapon()));
}
void Tower1::draw(QPainter *painter)
{
    painter->save();
    painter->setPen(Qt::blue);
    // 绘制攻击范围
    painter->drawEllipse(pos, showfirerange(), showfirerange());
//    painter->drawEllipse(pos,1,1);
    // 绘制偏转坐标,由中心+偏移=左上
    // 尺寸大小派上用场了,当然也可以直接获取图片大小,是一样的
    QPixmap sprite(":/image/shikuai.png");
    static const QPoint offsetPoint(-sprite.width()/2,-sprite.height()/2);
    // 绘制炮塔并选择炮塔
    // 这里将坐标原点移到pos,绘制的适合,就要加上那个偏移点到左上角
    painter->translate(pos);
    painter->drawPixmap(offsetPoint, pixmap);
    painter->restore();
}
void Tower1::attackEnemy()
{
    // 启动打炮模式
    mfireRateTimer->start(showfirerate());
}
void Tower1::chooseEnemyForAttack(Target1 *enemy)
{
    // 选择敌人,同时设置对敌人开火
    mchooseEnemy = enemy;
    // 这里启动timer,开始打炮
    attackEnemy();
    // 敌人自己要关联一个攻击者,这个用QList管理攻击者,因为可能有多个
    mchooseEnemy->getAttacked(this); //this function needs to be checked in enemy
}
void Tower1::shootWeapon()
{
    // 每次攻击,产生一个子弹
    // 子弹一旦产生,交由m_game管理,进行绘制
    Bullet *bullet = new Bullet(pos, mchooseEnemy->pos(), showdamage(), mchooseEnemy, mgame,showbullet());
//    QPainter *pa;
//    pa->save();
//    pa->setPen(Qt::red);
//    pa->drawEllipse(pos,1,1);
//    pa->restore();
    bullet->move();
    mgame->addBullet(bullet); //this function needs to be checked in battlefield1
}
void Tower1::targetKilled()
{
    // 目标死亡时,也需要取消关联
    // 取消攻击
    if (mchooseEnemy)
        mchooseEnemy = NULL;
    mfireRateTimer->stop();
    mrotationpixmap = 0.0;
}
void Tower1::lostSightOfEnemy()
{
    // 当敌人脱离炮塔攻击范围,要将炮塔攻击的敌人关联取消
    // 同时取消攻击
    mchooseEnemy->gotLostSight(this); //thie function needs to be checked in enemy
    if (mchooseEnemy)
        mchooseEnemy = NULL;
    mfireRateTimer->stop();
    mrotationpixmap = 0.0;
}

void Tower1::checkEnemyInRange()
{
    if (mchooseEnemy)
    {
        QVector2D normalized(mchooseEnemy->pos() - pos);
        normalized.normalize();
//        mrotationpixmap = qRadiansToDegrees(qAtan2(normalized.y(), normalized.x())) - 90;
        // 如果敌人脱离攻击范围
        if (!crash(pos, showfirerange(), mchooseEnemy->pos(), 1))
            lostSightOfEnemy();
    }
    else
    {
        // 遍历敌人,看是否有敌人在攻击范围内
        QList<Target1 *> enemyList = mgame->enemyList();
        foreach (Target1 *enemy, enemyList)
        {
            if (crash(pos,showfirerange(), enemy->pos(), 1))
            {
                chooseEnemyForAttack(enemy);
                break;
            }
        }
    }
}
int Tower1::showdamage()
{
    return this->damage;
}
int Tower1::showfirerate()
{
    return this->firerate;
}
int Tower1::showfirerange()
{
    return this->firerange;
}
QString Tower1::showbullet()
{
    return this->bullet;
}
Target1 * Tower1::targetenemy()
{

    return mchooseEnemy;
}
void Tower1::setenemy(Target1 *e)
{
    mchooseEnemy = e;
}

