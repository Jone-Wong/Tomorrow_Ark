#ifndef TOWER2_3_H
#define TOWER2_3_H

#include "tower2.h"
#include <QObject>
#include <QWidget>
#include "boomtower.h"

class Target2;
class LevelTwo;
class TowerPosition_2;

class Tower2_3: public BoomTower_2
{
public:
    Tower2_3(QPoint pos, LevelTwo *game,QString pixfilename);
    virtual void explode();

protected:
    int damage;

signals:

};
#endif // TOWER2_3_H
