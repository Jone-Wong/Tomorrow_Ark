#ifndef TOWER2_4_H
#define TOWER2_4_H

#include <QWidget>
#include <QObject>
#include "boomtower.h"

class Target2;
class LevelTwo;
class TowerPosition_2;

class Tower2_4: public BoomTower_2
{
public:
    Tower2_4(QPoint pos, LevelTwo *game,QString pixfilename);
    virtual void explode();

signals:

};
#endif // TOWER2_4_H
