#ifndef TOWER1_4_H
#define TOWER1_4_H

#include <QWidget>
#include <QObject>
#include "boomtower.h"

class Target1;
class LevelOne;
class TowerPosition;

class Tower1_4: public BoomTower
{
public:
    Tower1_4(QPoint pos, LevelOne *game,QString pixfilename);
    virtual void explode();

signals:

};


#endif // TOWER1_4_H
