#ifndef TOWER2_1_H
#define TOWER2_1_H

#include "tower2.h"
#include <QObject>


class Tower2_1 : public Tower2
{
public:
    Tower2_1(QPoint _pos,LevelTwo *game ,QString pixfilename, QString b);
    virtual int showdamage();
    virtual int showfirerange();
    virtual int showfirerate();
    virtual QString showbullet();
private:
    int firerange;
    int damage;
    int firerate;
    QString bullet;
};


#endif // TOWER2_1_H
