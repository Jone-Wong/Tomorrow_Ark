#ifndef UANDD_H
#define UANDD_H


#include <QPixmap>
#include <QObject>
#include <QPainter>
class TowerPosition;
class TowerPosition_2;
class UandD : public QObject
{
    Q_OBJECT
public:
    UandD(QPoint mpos, QString filename1, QString filename2);
    void drawone(QPainter *painter);
    void drawtwo(QPainter *painter);
    int showdisplay();
    void setdisplay(int towerclass);
    void resetdisplay();
    bool contain(QPoint cp);
    bool one(QPoint);
    bool two(QPoint);
    bool three(QPoint);
    bool four(QPoint);
    TowerPosition * tp;
private:
    QPixmap pixmap1;
    QPixmap pixmap2;
    QPoint pos;
    QSize size;
    int display;
signals:

public slots:
};



class UandD_2 : public QObject
{
    Q_OBJECT
public:
    UandD_2(QPoint mpos, QString filename1, QString filename2);
    void drawone(QPainter *painter);
    void drawtwo(QPainter *painter);
    int showdisplay();
    void setdisplay(int towerclass);
    void resetdisplay();
    bool contain(QPoint cp);
    bool one(QPoint);
    bool two(QPoint);
    bool three(QPoint);
    bool four(QPoint);
    TowerPosition_2 * tp;
private:
    QPixmap pixmap1;
    QPixmap pixmap2;
    QPoint pos;
    QSize size;
    int display;
signals:

public slots:
};


#endif // UANDD_H
