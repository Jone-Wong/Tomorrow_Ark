#include "lucky.h"
#include "s2c_button.h"
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>
#include <QTimer>
#include <QString>
#include <QFont>
#include <QFontDialog>
#include <QColor>
#include <QColorDialog>
#include <QPoint>
#include "chooselevel.h"

Lucky::Lucky(QWidget *parent) : QMainWindow(parent)
{
    //设置选择关卡界面大小
    this->setFixedSize(1024,576);

    //设置返回按钮
    S2C_Button * back_btn = new S2C_Button(":/image/lucky_button.png");
    back_btn->setParent(this);

    //返回按钮位置
    back_btn->move(670,430);

    //返回按钮链接主界面，以及弹跳效果
    connect(back_btn,&S2C_Button::clicked,this,[=](){

        //弹跳效果
        back_btn->zoomdown();
        back_btn->zoomup();

        //设置延时，以便看到效果
        QTimer::singleShot(300,this,[=](){
            emit chooseBack();
        });
    });

    //预先声明抽卡界面
    Fdcard * cardimage = new Fdcard;

    //声明支付界面
    Alipay * pay = new Alipay;

    //链接支付界面的按钮
    S2C_Button * pay_btn = new S2C_Button(":/image/alipay_button.png");

    //设置按钮的父类以及位置
    pay_btn->setParent(this);
    pay_btn -> move(440,430);

    //点击按钮的效果
    connect(pay_btn,&S2C_Button::clicked, this, [=](){

        //弹跳效果
        pay_btn->zoomdown();
        pay_btn->zoomup();

        QTimer::singleShot(300,this,[=](){

            //展示支付界面
            pay -> show();

            //只有点击付费按钮之后才可以抽卡 -> 哈哈哈哈哈老奸商了
            cardimage->showCard();
        });
    });

    //设置链接抽卡界面的按钮
    S2C_Button * fdcard_btn = new S2C_Button(":/image/findcard_button.png");

    //设置抽卡按钮的父类和位置
    fdcard_btn -> setParent(this);
    fdcard_btn -> move(210,430);

    //点击抽卡按钮的效果
    connect(fdcard_btn,&S2C_Button::clicked, this, [=](){

        //弹跳效果
        fdcard_btn->zoomdown();
        fdcard_btn->zoomup();

        QTimer::singleShot(300,this,[=](){
            this -> hide();
            cardimage -> show();

        });
    });

    //检验代码
    //    S2C_Button * start = new S2C_Button(":/image/findcard_button.png");
    //    start -> setParent(cardimage);
    //    start -> move(10,10);
    //    connect(start,&S2C_Button::clicked,this,[=](){
    //        Lucky::showCard();
    //    });


    //返回按钮
    connect(cardimage, &Fdcard::chooseBack, this, [=](){
        cardimage ->close();
        this ->show();
    });

}

void Lucky::paintEvent(QPaintEvent *){

    //选择关卡界面
    QPainter painter(this);

    //导入选择关卡界面图片
    QPixmap pixmap(":/image/findcard1.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);

}

void Fdcard::showCard(){

    //创建_卡1p-阿米娅_，设置位置以及图像
    Show_Card * a_card1 = new Show_Card(QPoint (40,100),":/image/card1.png");
    Show_Card * a_card2 = new Show_Card(QPoint(640,100),":/image/card2.png");

    //存入list中
    Card_list.push_back(a_card1);
    Card_list.push_back(a_card2);

    //刷新
    update();
}

Alipay::Alipay(QWidget *parent) : QMainWindow(parent)
{

    //设置支付二维码窗口的大小
    this->setFixedSize(570,576);
}

void Alipay::paintEvent(QPaintEvent *){

    //选择关卡界面
    QPainter painter(this);

    //导入选择关卡界面图片
    QPixmap pixmap(":/image/ali.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}

Fdcard::Fdcard(QWidget *parent) : QMainWindow(parent)
{
    //设置选择关卡界面大小
    this->setFixedSize(1024,576);

    //设置返回按钮
    S2C_Button * back_btn = new S2C_Button(":/image/lucky_button.png");
    back_btn->setParent(this);

    //返回按钮位置
    back_btn->move(440,430);

    //返回按钮链接主界面，以及弹跳效果
    connect(back_btn,&S2C_Button::clicked,this,[=](){

        //弹跳效果
        back_btn->zoomdown();
        back_btn->zoomup();

        //设置延时，以便看到效果
        QTimer::singleShot(300,this,[=](){
            emit chooseBack();
        });
    });

}

void Fdcard::paintEvent(QPaintEvent *){
    //选择关卡界面
    QPainter painter(this);

    //导入选择关卡界面图片
    QPixmap pixmap(":/image/findcard2.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);

    showInfo(&painter);

    //循环遍历形成动画
    foreach(Show_Card * card, Card_list){
        card -> draw(&painter);
    }
}

void Fdcard::showInfo(QPainter * painter){

    //保存画笔
    painter -> save();

    //设置画笔
    painter -> setPen(Qt::red);



    //设置位置、内容
    painter -> drawText(QRect(350,50,500,500),QString("๑乛◡乛๑你已获得★★★稀有干员★★★！(●´∀｀●)"));

    //还原画笔
    painter -> restore();
}

Show_Card::Show_Card(QPoint pos, QString pixFileName) : QObject(0), pixmap(pixFileName)
{

    //设置_卡1-阿米娅_的位置
    _pos = pos;
}

void Show_Card::draw(QPainter *painter){

    //画出_卡1-阿米娅_
    painter->drawPixmap(_pos, pixmap);
}
