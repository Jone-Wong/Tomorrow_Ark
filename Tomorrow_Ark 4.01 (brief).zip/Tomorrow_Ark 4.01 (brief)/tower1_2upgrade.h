#ifndef TOWER1_2UPGRADE_H
#define TOWER1_2UPGRADE_H
#include <QObject>
#include "tower1.h"
#include "levelone.h"

class Tower1_2upgrade : public Tower1
{
public:
    Tower1_2upgrade(QPoint _pos, LevelOne *game ,QString pixfilename, QString b);
    virtual int showdamage();
    virtual int showfirerange();
    virtual int showfirerate();
    virtual QString showbullet();
private:
    int firerange;
    int damage;
    int firerate;
    QString bullet;
  //  Enemy * mchooseEnemy;
};


#endif // TOWER1_2UPGRADE_H
