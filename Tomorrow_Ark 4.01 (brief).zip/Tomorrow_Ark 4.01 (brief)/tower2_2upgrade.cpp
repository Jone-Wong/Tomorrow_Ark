#include "tower2_2upgrade.h"

Tower2_2upgrade::Tower2_2upgrade(QPoint _pos, LevelTwo *game ,QString pixfilename, QString b): Tower2 (_pos, game, pixfilename)
{
    firerange=300;
    firerate=2000;
    damage=120;
    bullet=b;
}

int Tower2_2upgrade::showdamage()
{
    return this->damage;
}
int Tower2_2upgrade::showfirerate()
{
    return this->firerate;
}
int Tower2_2upgrade::showfirerange()
{
    return this->firerange;
}
QString Tower2_2upgrade::showbullet()
{
    return this->bullet;
}
