#ifndef TOWER1_2_H
#define TOWER1_2_H

#include "tower1.h"
#include <QObject>


class Tower1_2 : public Tower1
{
public:
    Tower1_2(QPoint _pos, LevelOne *game ,QString pixfilename, QString b);
    virtual int showdamage();
    virtual int showfirerange();
    virtual int showfirerate();
    virtual QString showbullet();
private:
    int firerange;
    int damage;
    int firerate;
    QString bullet;
};

#endif // TOWER1_2_H
