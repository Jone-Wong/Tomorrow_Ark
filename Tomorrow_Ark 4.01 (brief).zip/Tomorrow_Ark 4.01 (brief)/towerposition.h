#ifndef TOWERPOSITION_H
#define TOWERPOSITION_H

#include <QObject>
#include <QPoint>
#include <QPixmap>
#include "uandd.h"
#include "tower2.h"

class SelectionCircle;
class SelectionCircle_2;
class Tower1;
class Tower2;
class BoomTower;
class BoomTower_2;
class UandD;

class TowerPosition
{
public:
    TowerPosition(QPoint pos, QString filename);
    void settowerclass(int towerclass);
    int Towerclass();
    QPoint centerPos();
    bool containPoint(QPoint &pos);
    void draw(QPainter *painter);
    SelectionCircle * cs;
    UandD * uad;
    Tower1 * t;
    BoomTower * bt;

private:
    QPoint		m_pos;
    int		m_Towerclass;
    QPixmap		m_sprite;
    QSize ms_fixedSize;

signals:

};


class TowerPosition_2
{
public:
    TowerPosition_2(QPoint pos, QString filename);
    void settowerclass(int towerclass);
    int Towerclass();
    QPoint centerPos();
    bool containPoint(QPoint &pos);
    void draw(QPainter *painter);
    SelectionCircle_2 * cs;
    UandD_2 * uad;
    Tower2 * t;
    BoomTower_2 * bt;

private:
    QPoint		m_pos;
    int		m_Towerclass;
    QPixmap		m_sprite;
    QSize ms_fixedSize;

signals:

};

#endif // TOWERPOSITION_H
