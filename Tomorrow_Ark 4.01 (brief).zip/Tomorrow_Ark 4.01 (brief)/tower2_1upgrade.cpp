#include "tower2_1upgrade.h"

Tower2_1upgrade::Tower2_1upgrade(QPoint _pos, LevelTwo *game ,QString pixfilename, QString b): Tower2 (_pos, game, pixfilename)
{
    firerange=150;
    firerate=400;
    damage=15;
    bullet = b;
}

int Tower2_1upgrade::showdamage()
{
    return this->damage;
}
int Tower2_1upgrade::showfirerate()
{
    return this->firerate;
}
int Tower2_1upgrade::showfirerange()
{
    return this->firerange;
}
QString Tower2_1upgrade::showbullet()
{
    return this->bullet;
}
