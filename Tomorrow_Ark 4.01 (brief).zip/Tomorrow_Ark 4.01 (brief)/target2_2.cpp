#include "target2_2.h"

Target2_2::Target2_2(WayPoint *startWayPoint, LevelTwo *game, QString filename): Target2 (startWayPoint, game)
{
    QPixmap p(filename);
    m_sprite=p;
    ms_fixedSize=QSize(m_sprite.width(),m_sprite.height());
    m_maxHp=150;
    m_currentHp=150;
    m_walkingSpeed=1.0;
    awardgold=400;
}
double Target2_2::showmaxhp()
{
    return this->m_maxHp;
}

double Target2_2::showcurrenthp()
{
    return this->m_currentHp;
}

double Target2_2::showwalkingspeed()
{
    return this->m_walkingSpeed;
}

int Target2_2::showawardgold()
{
    return this->awardgold;
}

void Target2_2::setcurrenthp(double newhp)
{
    this->m_currentHp=newhp;
}

QSize Target2_2::showsize()
{
    return this->ms_fixedSize;
}

QPixmap Target2_2::showpixmap()
{
    return this->m_sprite;
}
void Target2_2::setwalkingspeed(double newspeed)
{
    this->m_walkingSpeed=newspeed;
}
