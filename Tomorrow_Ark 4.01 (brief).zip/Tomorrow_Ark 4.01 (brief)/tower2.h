#ifndef TOWER2_H
#define TOWER2_H

#include <QObject>
#include <QPoint>
#include <QPixmap>
#include "bullet.h"
#include "leveltwo.h"

class Target2;
class LevelTwo;
class Bullet_2;
class TowerPosition_2;

class Tower2 : QObject
{
    Q_OBJECT
public:
    Tower2(QPoint pos, LevelTwo *game,QString pixfilename);
    void draw(QPainter * painter);
    void targetKilled();
    void attackEnemy();
    void chooseEnemyForAttack(Target2 * enemy);
    void lostSightOfEnemy();
    void checkEnemyInRange();
    virtual int showdamage();
    virtual int showfirerange();
    virtual int showfirerate();
    virtual QString showbullet();
    void setenemy(Target2 * e);
    Target2 * targetenemy();
    TowerPosition_2 * tp;
public slots:
    void shootWeapon();
protected:
    QPoint pos;
    bool mattacking;
    QSize ms_fixedSize;
    QPixmap pixmap;
    int firerange;
    int damage;
    int firerate;
    QString bullet;
    double mrotationpixmap;
    Target2 * mchooseEnemy;
    QTimer * mfireRateTimer;
    LevelTwo * mgame;
signals:
};


#endif // TOWER2_H
