#include "tower2_1.h"
Tower2_1::Tower2_1(QPoint _pos, LevelTwo *game ,QString pixfilename, QString b): Tower2 (_pos, game, pixfilename)
{
    firerange=150;
    firerate=400;
    damage=10;
    bullet = b;
}

int Tower2_1::showdamage()
{
    return this->damage;
}
int Tower2_1::showfirerate()
{
    return this->firerate;
}
int Tower2_1::showfirerange()
{
    return this->firerange;
}
QString Tower2_1::showbullet()
{
    return this->bullet;
}
