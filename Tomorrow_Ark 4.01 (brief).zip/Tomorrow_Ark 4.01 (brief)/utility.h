#ifndef UTILITY_H
#define UTILITY_H
#include <QtMath>
#include <QPoint>

inline bool crash(QPoint point1, int r1, QPoint point2, int r2)
{
    double dx = point1.x() - point2.x();
    double dy = point1.y() - point2.y();
    double distance = qSqrt(dx * dx + dy * dy);
    if (distance <= r1 + r2)
        return true;
    return false;
}

#endif // UTILITY_H
