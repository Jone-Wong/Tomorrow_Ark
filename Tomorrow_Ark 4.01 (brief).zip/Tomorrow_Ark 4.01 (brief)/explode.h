#ifndef EXPLODE_H
#define EXPLODE_H

#include <QObject>
#include <QPoint>
#include "levelone.h"
#include "leveltwo.h"

class LevelOne;
class LevelTwo;

class Explode : public QObject
{
    Q_OBJECT
public:
    Explode(QPoint pos, LevelOne * game, QString filename);
    QPoint showpos();
    QString showpicture();
private:
    QPoint mpos;
    LevelOne * m_game;
    QString filename;
public slots:
    void deleteexplode();
};

class Explode_2 : public QObject
{
    Q_OBJECT
public:
    Explode_2(QPoint pos, LevelTwo * game, QString filename);
    QPoint showpos();
    QString showpicture();
private:
    QPoint mpos;
    LevelTwo * m_game;
    QString filename;
public slots:
    void deleteexplode();
};

#endif // EXPLODE_H
