#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMainWindow>
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>
#include <QTimer>
#include <QMovie>
#include <QMediaPlayer>
#include <QMediaPlaylist>
#include <QVideoWidget>
#include "s2c_button.h"
#include "chooselevel.h"
#include "levone_button.h"
#include "levelone.h"
#include "settvr_button.h"
#include "story.h"
#include <QHBoxLayout>
#include <QVideoWidget>
#include <QDebug>
#include <iostream>
using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    //设置游戏界面窗口大小
    this->setFixedSize(1024,576);
    ui->setupUi(this);


        //这是单曲播放一遍的代码
//    //设置对象
//    player = new QMediaPlayer;

//    player->setPlaylist(playlist);

//    connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));

//    //标注路径
//    player->setMedia(QUrl("../big_res/b_ui_win.wav"));

//    //设置音量
//    player->setVolume(30);


//    //开始播放
//    player->play();


    //这是曲目列表循环播放的代码
    playlist = new QMediaPlaylist(this);
    playlist->addMedia(QUrl("../big_res/welcmbgm.mp3"));
    playlist->setCurrentIndex(1);
    playlist->setPlaybackMode(QMediaPlaylist::CurrentItemInLoop);

    player = new QMediaPlayer(this);
    player->setPlaylist(playlist);

    videoWidget = new QVideoWidget(this);
    player->setVideoOutput(videoWidget);
    videoWidget->hide();
    player->setVolume(30);
    player->play();


    //设置主界面背景动画
    movie = new QMovie(this);

    //文件较大，故使用相对路径/////////导出程序时不要忘记附带视频///////////
    movie->setFileName(QString("../big_res/welcome.gif"));

    //开始播放
    movie->start();


    //计时，并定时刷新界面，保证流畅性
    QTimer * timer = new QTimer (this);
    connect (timer, &QTimer::timeout, this, &MainWindow::updateScence);

    //每十毫秒刷新一次界面
    timer->start(10);


    //设置一个按钮
    S2C_Button * btn = new S2C_Button(":/image/button.png");

    //设置背景故事跳转按钮
    S2C_Button * sbtn = new S2C_Button(":/image/stry_button.png");

    //设置按钮的父类和位置
    btn->setParent(this);
    btn->move(445,375);

    //设置父类及位置
    sbtn -> setParent(this);
    sbtn -> move(930,400);

    //创建选择关卡页面
    ChooseLevel * scene = new ChooseLevel;

    //创建故事背景介绍页面
    Story * exp = new Story;

    //设置按钮弹跳效果
    connect(btn,&QPushButton::clicked,this,[=](){

        //弹跳效果
        btn->zoomdown();
        btn->zoomup();

        player->setVolume(0);

        scene->player->setVolume(30);

        //设置时间间隔
        QTimer::singleShot(300,this,[=](){

            //界面的隐藏和显现
            this->hide();
            scene->show();
        });
    });

    connect(sbtn, &QPushButton::clicked,this,[=](){

        //按钮弹跳效果
        sbtn -> zoomdown();
        sbtn -> zoomup();

        //设置延后效果
        QTimer::singleShot(300,this,[=](){

            this->hide();
            exp->show();
        });
    });

    //由选择关卡界面返回主界面按钮
    connect(scene,&ChooseLevel::chooseBack,this,[=](){

        player->setVolume(30);

        scene->player->setVolume(0);

        //界面的隐藏和显现
        scene->hide();
        this->show();
    });

    //由选择关卡界面返回主界面按钮
    connect(exp,&Story::chooseBack,this,[=](){


        //界面的隐藏和显现
        exp->hide();
        this->show();
    });

    //导入第一关按钮图像
    Levone_Button * lvonebtn = new Levone_Button(":/image/level_one.png");

    //设置第一关按钮父类和位置
    lvonebtn->setParent(scene);
    lvonebtn->move(50,380);

    //设置第一关背景
    LevelOne * levone = new LevelOne;

    connect(lvonebtn,&QPushButton::clicked,this,[=](){

        //第一关按钮弹跳效果
        lvonebtn->zoomdown();
        lvonebtn->zoomup();

        //设置时间间隔
        QTimer::singleShot(300,this,[=](){

            //画面的隐藏与显现
            this->hide();
            levone->show();

            scene->player->setVolume(0);
        });
    });


    connect(levone,&LevelOne::chooseBack,this,[=](){

        scene->player->setVolume(30);

        //界面的隐藏和显现
        levone->hide();
        scene->show();
    });


}

void MainWindow::paintEvent(QPaintEvent *){

    //主界面
    QPainter painter(this);

    //导入主界面背景
    painter.drawPixmap(0,0,width(),height(), movie->currentPixmap());

    showInfo(&painter);
}

void MainWindow::showInfo(QPainter * painter){

    //保存画笔
    painter -> save();

    //设置画笔
    painter -> setPen(Qt::white);

    //设置位置、内容
    painter -> drawText(QRect(340,540,500,100),QString("Copy Right @ Wang Kaixin , June 25 , 2020  _Version 4.01_"));

    //还原画笔
    painter -> restore();
}

void MainWindow::updateScence(){

    //刷新
    update();
}

MainWindow::~MainWindow()
{
    delete ui;
}
