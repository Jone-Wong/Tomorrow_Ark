#ifndef BOOMTOWER_H
#define BOOMTOWER_H

#include <QObject>
#include <QWidget>
#include "levelone.h"
#include "target1.h"
#include "towerposition.h"

class Target1;
class LevelOne;
class TowerPosition;
class BoomTower: QObject
{
    Q_OBJECT
public:
    BoomTower(QPoint pos, LevelOne *game,QString pixfilename);
    void draw(QPainter * painter);
    void checkEnemyInRange();
    virtual void explode();
    TowerPosition * tp;
    QPoint showcenterpos();
protected:
    QPoint pos;
    QSize ms_fixedSize;
    QPixmap pixmap;
    int triggerrange;
    int damagerange;
    LevelOne * mgame;
signals:
};

class BoomTower_2 : QObject
{
    Q_OBJECT
public:
    BoomTower_2(QPoint pos, LevelTwo *game,QString pixfilename);
    void draw(QPainter * painter);
    void checkEnemyInRange();
    virtual void explode();
    TowerPosition_2 * tp;
    QPoint showcenterpos();
protected:
    QPoint pos;
    QSize ms_fixedSize;
    QPixmap pixmap;
    int triggerrange;
    int damagerange;
    LevelTwo * mgame;
signals:
};


#endif // BOOMTOWER_H
