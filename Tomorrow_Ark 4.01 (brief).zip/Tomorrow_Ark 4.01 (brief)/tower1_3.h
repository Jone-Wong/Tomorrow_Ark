#ifndef TOWER1_3_H
#define TOWER1_3_H

#include "tower1.h"
#include <QObject>
#include <QWidget>
#include "boomtower.h"

class Target1;
class LevelOne;
class TowerPosition;

class Tower1_3: public BoomTower
{
public:
    Tower1_3(QPoint pos, LevelOne *game,QString pixfilename);
    virtual void explode();

protected:
    int damage;

signals:

};

#endif // TOWER1_3_H
