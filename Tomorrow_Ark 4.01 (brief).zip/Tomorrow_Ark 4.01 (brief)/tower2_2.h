#ifndef TOWER2_2_H
#define TOWER2_2_H

#include "tower2.h"
#include <QObject>


class Tower2_2 : public Tower2
{
public:
    Tower2_2(QPoint _pos, LevelTwo *game ,QString pixfilename, QString b);
    virtual int showdamage();
    virtual int showfirerange();
    virtual int showfirerate();
    virtual QString showbullet();
private:
    int firerange;
    int damage;
    int firerate;
    QString bullet;
};


#endif // TOWER2_2_H
