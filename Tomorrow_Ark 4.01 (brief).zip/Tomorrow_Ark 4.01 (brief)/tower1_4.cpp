#include "tower1_4.h"
#include "levelone.h"
#include "target1.h"
#include "utility.h"
#include <QPainter>
#include <QMediaPlayer>
Tower1_4::Tower1_4(QPoint pos, LevelOne *game,QString pixfilename):BoomTower(pos, game, pixfilename)
{

}
void Tower1_4::explode()
{
    QList<Target1 *> enemyList = mgame->enemyList();
    foreach (Target1 *enemy, enemyList)
    {
        if (crash(pos,damagerange, enemy->pos(), 1))
        {
            QMediaPlayer * player = new QMediaPlayer;
            player->setMedia(QUrl("../big_res/ifrit_exp.mp3"));
            player->setVolume(100);
            player->play();
            enemy->resetspeed();
        }
    }
    mgame->removeboomtower(this);
    mgame->addexplode(pos, ":/image/ExplosionEffect6yl.png");
}
