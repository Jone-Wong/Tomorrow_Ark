#ifndef TARGET2_H
#define TARGET2_H
#include <QObject>
#include <QPropertyAnimation>
#include <QPoint>
#include <QPixmap>
#include <QPainter>
#include <QWidget>
#include <QSize>
#include "waypoint.h"
#include "leveltwo.h"
#include "tower2.h"

class LevelOne;
class WayPoint;
class Tower2;
class LevelTwo;

class Target2 : public QObject
{
    Q_OBJECT
public:
    Target2(WayPoint *startWayPoint, LevelTwo *game);//√
    void draw(QPainter *painter);//√
    void move();
    void getDamage(int damage);
    void getRemoved();
    QPoint pos() const;
    void getAttacked(Tower2 *attacker);
    void gotLostSight(Tower2 *attacker);
    void resetspeed();
    virtual double showmaxhp();
    virtual double showcurrenthp();
    virtual double showwalkingspeed();
    virtual int showawardgold();
    virtual void setcurrenthp(double newhp);
    virtual void setwalkingspeed(double newspeed);
    virtual QPixmap showpixmap();
    virtual QSize showsize();
public slots:
    void doActivate();
protected:
    bool			m_active;
    double				m_maxHp;
    double				m_currentHp;
    double			m_walkingSpeed;
    int awardgold;
    QPoint			m_pos;
    WayPoint *		m_destinationWayPoint;
    LevelTwo *	m_game;
    QPixmap	m_sprite;
    QSize ms_fixedSize;
    QList<Tower2 *>	m_attackedTowersList;

};
#endif // TARGET2_H
