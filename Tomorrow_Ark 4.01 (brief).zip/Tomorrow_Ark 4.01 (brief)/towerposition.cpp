#include "towerposition.h"
#include <QPainter>
#include <iostream>

TowerPosition::TowerPosition(QPoint pos, QString filename)
    : m_pos(pos)
    , m_Towerclass(0)
{
    QPixmap p1(filename);
    m_sprite=p1;
    ms_fixedSize=QSize(m_sprite.width(),m_sprite.height());
}

QPoint TowerPosition::centerPos()
{
    QPoint offsetPoint(ms_fixedSize.width() / 2, ms_fixedSize.height() / 2);
    return m_pos + offsetPoint;
}

bool TowerPosition::containPoint(QPoint &pos)
{
    bool isXInHere = m_pos.x() < pos.x() && pos.x() < (m_pos.x() + ms_fixedSize.width());
    bool isYInHere = m_pos.y() < pos.y() && pos.y() < (m_pos.y() + ms_fixedSize.height());
    return isXInHere && isYInHere;
}

int TowerPosition::Towerclass()
{
    return m_Towerclass;
}

void TowerPosition::settowerclass(int towerclass)
{
    m_Towerclass = towerclass;
}

void TowerPosition::draw(QPainter *painter)
{
    painter -> drawPixmap(m_pos.x(), m_pos.y(), m_sprite);
}





TowerPosition_2::TowerPosition_2(QPoint pos, QString filename)
    : m_pos(pos)
    , m_Towerclass(0)
{
    QPixmap p1(filename);
    m_sprite=p1;
    ms_fixedSize=QSize(m_sprite.width(),m_sprite.height());
}

QPoint TowerPosition_2::centerPos()
{
    QPoint offsetPoint(ms_fixedSize.width() / 2, ms_fixedSize.height() / 2);
    return m_pos + offsetPoint;
}

bool TowerPosition_2::containPoint(QPoint &pos)
{
    bool isXInHere = m_pos.x() < pos.x() && pos.x() < (m_pos.x() + ms_fixedSize.width());
    bool isYInHere = m_pos.y() < pos.y() && pos.y() < (m_pos.y() + ms_fixedSize.height());
    return isXInHere && isYInHere;
}

int TowerPosition_2::Towerclass()
{
    return m_Towerclass;
}

void TowerPosition_2::settowerclass(int towerclass)
{
    m_Towerclass = towerclass;
}

void TowerPosition_2::draw(QPainter *painter)
{
    painter -> drawPixmap(m_pos.x(), m_pos.y(), m_sprite);
}
