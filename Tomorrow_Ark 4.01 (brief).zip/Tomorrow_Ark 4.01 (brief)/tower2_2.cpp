#include "tower2_2.h"

Tower2_2::Tower2_2(QPoint _pos, LevelTwo *game ,QString pixfilename, QString b): Tower2(_pos, game, pixfilename)
{
    firerange=300;
    firerate=2000;
    damage=100;
    bullet=b;
}

int Tower2_2::showdamage()
{
    return this->damage;
}
int Tower2_2::showfirerate()
{
    return this->firerate;
}
int Tower2_2::showfirerange()
{
    return this->firerange;
}
QString Tower2_2::showbullet()
{
    return this->bullet;
}
