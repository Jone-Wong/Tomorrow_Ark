#include "explode.h"
#include "levelone.h"
#include "leveltwo.h"

Explode::Explode(QPoint pos, LevelOne * game, QString filename):QObject (0)
{

    //对各变量进行初始化
    mpos=pos;
    m_game=game;
    this->filename=filename;
}

QPoint Explode::showpos()
{

    //返回位置
    return this->mpos;
}

void Explode::deleteexplode()
{

    //删除
    m_game->removeexplode(this);
    delete this;
}

QString Explode::showpicture()
{

    //返回文件名字
    return this->filename;
}



Explode_2::Explode_2(QPoint pos, LevelTwo * game, QString filename):QObject (0)
{

    //对各变量进行初始化
    mpos=pos;
    m_game=game;
    this->filename=filename;
}

QPoint Explode_2::showpos()
{

    //返回位置
    return this->mpos;
}

void Explode_2::deleteexplode()
{

    //删除
    m_game->removeexplode(this);
    delete this;
}

QString Explode_2::showpicture()
{

    //返回文件名字
    return this->filename;
}
