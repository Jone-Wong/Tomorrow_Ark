#include "tower1_2upgrade.h"

Tower1_2upgrade::Tower1_2upgrade(QPoint _pos, LevelOne *game ,QString pixfilename, QString b): Tower1 (_pos, game, pixfilename)
{
    firerange=300;
    firerate=2000;
    damage=120;
    bullet=b;
}

int Tower1_2upgrade::showdamage()
{
    return this->damage;
}
int Tower1_2upgrade::showfirerate()
{
    return this->firerate;
}
int Tower1_2upgrade::showfirerange()
{
    return this->firerange;
}
QString Tower1_2upgrade::showbullet()
{
    return this->bullet;
}
