#ifndef LEVELONE_H
#define LEVELONE_H

#include <QMainWindow>
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QList>
#include "target1.h"
#include "target2.h"
#include "towerposition.h"
#include "tower1.h"
#include "selectioncircle.h"
#include "explode.h"
#include "boomtower.h"
#include "uandd.h"

class Target1;
class Target2;
class WayPoint;
class Bullet;
class Settvr_Button;
class Explode;
class SelectionCircle;
class Tower1_3;
class BoomTower;


class LevelOne : public QMainWindow
{
    Q_OBJECT
public:
   explicit LevelOne(QWidget *parent = nullptr);
   void paintEvent(QPaintEvent*);
   void showInfo(QPainter *);
   void loadTowerPositions();
   void addWayPoints();
   void getHpDamage(int damage/* = 1*/);
   void mousePressEvent(QMouseEvent *event);
   bool canBuyTower1();
   bool canBuyTower2();
   bool canBuyTower3();
   bool canBuyTower4();
   void removedEnemy(Target1 *enemy);
   bool loadWave();
   void addBullet(Bullet * b);
   QList<Target1 *> enemyList() const;
   void removedBullet(Bullet *bullet);
   void removeboomtower(BoomTower *bt);
   void removetower(Tower1 *t);
   void awardgold(int gold);
   void doGameOver();
   void loadselectioncircle();
   void DrawExplosion(QPainter * painter, QPoint coor, QString filename);
   void addexplode(QPoint p, QString filename);
   void removeexplode(Explode * e);
   void loaduandd();


public slots:
   void updateMap();
   void triggerwave();

private:
   int fee = 10000;
   int m_waves = 1;
   int health = 5;
   bool m_gameWin = false;
   bool m_gameEnd = false;
   QList<Tower1 *> tower1_list;
   QList<Target1*> target1_list;
   QList<TowerPosition *> m_towerPositionsList;
   QList<WayPoint *> m_wayPointsList1;
   QList<WayPoint *> m_wayPointsList2;
   QList<WayPoint *> m_wayPointsList3;
   QList<Bullet *>	m_bulletList;
   QList<SelectionCircle *> m_selectioncircleList;
   QList<BoomTower *> m_boomtowerList;
   QList<Explode *> m_explodeList;
   QList<UandD *> m_uanddList;

signals:
    void chooseBack();

};

#endif // LEVELONE_H
