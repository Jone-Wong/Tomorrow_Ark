#ifndef TARGET1_H
#define TARGET1_H

#include <QObject>
#include <QPropertyAnimation>
#include <QPoint>
#include <QPixmap>
#include <QPainter>
#include <QWidget>
#include <QSize>
#include "tower1.h"
#include "levelone.h"
#include "waypoint.h"

class LevelOne;
class WayPoint;
class Tower1;

class Target1 : public QObject
{
    Q_OBJECT
public:
    Target1(WayPoint *startWayPoint, LevelOne *game);//√
    void draw(QPainter *painter);//√
    void move();
    void getDamage(int damage);
    void getRemoved();
    QPoint pos() const;
    void getAttacked(Tower1 *attacker);
    void gotLostSight(Tower1 *attacker);
    void resetspeed();
    virtual double showmaxhp();
    virtual double showcurrenthp();
    virtual double showwalkingspeed();
    virtual int showawardgold();
    virtual void setcurrenthp(double newhp);
    virtual void setwalkingspeed(double newspeed);
    virtual QPixmap showpixmap();
    virtual QSize showsize();
public slots:
    void doActivate();
protected:
    bool			m_active;
    double				m_maxHp;
    double				m_currentHp;
    double			m_walkingSpeed;
    int awardgold;
    QPoint			m_pos;
    WayPoint *		m_destinationWayPoint;
    LevelOne *	m_game;
    QPixmap	m_sprite;
    QSize ms_fixedSize;
    QList<Tower1 *>	m_attackedTowersList;

};

#endif // TARGET1_H
