#include "target2.h"
#include <QVector2D>
#include "waypoint.h"
#include "utility.h"
#include "levelone.h"
#include "leveltwo.h"
#include <iostream>
using namespace std;
static const int Health_Bar_Width = 40;

Target2::Target2(WayPoint *startWayPoint, LevelTwo *game)
    : QObject(0)
    , m_pos(startWayPoint->pos())
{
     m_active = false;
     m_destinationWayPoint = startWayPoint->nextWayPoint();
     m_game = game;
}

void Target2::draw(QPainter *painter)
{
    if (!m_active)
        return;

    painter->save();

    QPoint healthBarPoint = m_pos + QPoint(-Health_Bar_Width / 2-1 , -showsize().height()/2-3);
    // 绘制血条
    painter->setPen(Qt::NoPen);
    painter->setBrush(Qt::red);
    QRect healthBarBackRect(healthBarPoint, QSize(Health_Bar_Width, 2));
    painter->drawRect(healthBarBackRect);

    painter->setBrush(Qt::green);
    QRect healthBarRect(healthBarPoint, QSize(showcurrenthp() / showmaxhp()* Health_Bar_Width, 2));
    painter->drawRect(healthBarRect);

    // 绘制偏转坐标,由中心+偏移=左上
    static const QPoint offsetPoint(-showsize().width() / 2, -showsize().height() / 2 -5);
    painter->translate(m_pos);
//    painter->rotate(m_rotationSprite);
    // 绘制敌人
    painter->drawPixmap(offsetPoint, showpixmap());

    painter->restore();
}
void Target2::move()
{
    if (!m_active)
        return;
    if (crash(m_pos, 1, m_destinationWayPoint->pos(), 1))
    {
        // 敌人抵达了一个航点
        if (m_destinationWayPoint->nextWayPoint())
        {
            // 还有下一个航点
            m_pos = m_destinationWayPoint->pos();
            m_destinationWayPoint = m_destinationWayPoint->nextWayPoint();
        }
        else
        {
            // 表示进入基地
            m_game->getHpDamage(1);
            getRemoved();
            return;
        }
    }
    // 还在前往航点的路上
    // 目标航点的坐标
    QPoint targetPoint = m_destinationWayPoint->pos();
    // 未来修改这个可以添加移动状态,加快,减慢,m_walkingSpeed是基准值
    // 向量标准化
    double movementSpeed = showwalkingspeed();
    QVector2D normalized(targetPoint - m_pos);
    normalized.normalize();
    m_pos = m_pos + normalized.toPoint() * movementSpeed;
    // 确定敌人选择方向
    // 默认图片向左,需要修正180度转右
//    m_rotationSprite = qRadiansToDegrees(qAtan2(normalized.y(), normalized.x())) + 180;
}

void Target2::doActivate()
{
    m_active = true;
}

void Target2::getAttacked(Tower2 *attacker)
{
    m_attackedTowersList.push_back(attacker);
}

// 表明敌人已经逃离了攻击范围
void Target2::gotLostSight(Tower2 *attacker)
{
    cout<<"wow"<<endl;
    m_attackedTowersList.removeOne(attacker);
}

QPoint Target2::pos() const
{
    return m_pos;
}

void Target2::getRemoved()
{
    foreach (Tower2 *attacker, m_attackedTowersList)
        attacker->targetKilled();//通过这个函数让塔指向敌人的指针变为NULL
    // 通知game,此敌人已经阵亡
    m_game->removedEnemy(this);
}

void Target2::getDamage(int damage)
{
    setcurrenthp(showcurrenthp()-damage);
    //m_currentHp -= damage;
    // 阵亡,需要移除
    if (showcurrenthp() <= 0)
    {
        m_game->awardgold(showawardgold());
        getRemoved();
    }
}

void Target2::resetspeed()
{
    setwalkingspeed(showwalkingspeed()/2);
}

double Target2::showmaxhp()
{
    return this->m_maxHp;
}

double Target2::showcurrenthp()
{
    return this->m_currentHp;
}

double Target2::showwalkingspeed()
{
    return this->m_walkingSpeed;
}

int Target2::showawardgold()
{
    return this->awardgold;
}

void Target2::setcurrenthp(double newhp)
{
    this->m_currentHp=newhp;
}

QSize Target2::showsize()
{
    return this->ms_fixedSize;
}

QPixmap Target2::showpixmap()
{
    return this->m_sprite;
}
void Target2::setwalkingspeed(double newspeed)
{
    this->m_walkingSpeed=newspeed;
}
