#ifndef LEVELTWO_H
#define LEVELTWO_H

#include <QMainWindow>
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include "tower1.h"
#include <QList>
#include "target1.h"
#include "target2.h"


class LevelTwo : public QMainWindow
{
    Q_OBJECT
public:
    explicit LevelTwo(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);
    void set_tower1();
    void addTarget1();
    void addTarget2();
    void updateScence();

private:
    QList<Tower1 *> tower1_list;
    QList<Target1*> target1_list;
    QList<Target2*> target2_list;

signals:


};

#endif // LEVELTWO_H
