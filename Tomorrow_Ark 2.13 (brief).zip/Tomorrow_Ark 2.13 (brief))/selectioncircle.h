#ifndef SELECTIONCIRCLE_H
#define SELECTIONCIRCLE_H

#include <QPixmap>
#include <QObject>
#include <QPainter>

class SelectionCircle : public QObject
{
    Q_OBJECT
public:
    SelectionCircle(QPoint mpos, QString filename);
    void draw(QPainter *painter);
private:
    QPixmap pixmap;
    QPoint pos;
    QSize size;
signals:

public slots:

};
#endif // SELECTIONCIRCLE_H
