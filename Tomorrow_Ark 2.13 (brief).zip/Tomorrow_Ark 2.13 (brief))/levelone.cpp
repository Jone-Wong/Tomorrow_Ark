#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QMediaPlayer>
#include "levelone.h"
#include <QTimer>
#include "tower1.h"
#include "waypoint.h"
#include "towerposition.h"
#include "target1.h"
#include "bullet.h"
#include "selectioncircle.h"
#include "settvr_button.h"

#include<stdio.h>
#include<stdlib.h>
#include <iostream>

using namespace std;

#define random(x) (rand()%x)


LevelOne::LevelOne(QWidget *parent) : QMainWindow(parent)
{

    //设置界面大小
    setFixedSize(1024,576);

    //    mybutton * back_btn = new mybutton(":/pictures/pictures/return0.jpg");
    //    back_btn->setParent(this);
    //    back_btn->move(100,40);
    //    connect(back_btn,&mybutton::clicked,this,[=](){
    //        emit chooseBack();
    //    });

    //加载塔位置
    loadTowerPositions();

    //加载路径点
    addWayPoints();

    //    loadWave();

    //设置敌人开始进入按钮
    Settvr_Button * startwave = new Settvr_Button(":/image/settower_button.png");

    //设置按钮父类
    startwave->setParent(this);

    //设置按钮位置
    startwave->move(660, 0);

    //点击按钮链接的操作
    connect(startwave, SIGNAL(clicked()), this, SLOT(triggerwave()));

    //设置计时，不断刷新界面
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(updateMap()));
    timer->start(10);
}

void LevelOne::paintEvent(QPaintEvent *)
{

    //判断游戏是否结束
    if (m_gameEnd || m_gameWin)
    {

        //输出任务完成或任务失败
        QString text = m_gameEnd ? "Mission Failed!!!" : "Mission Accomplished!!!";

        //设置画笔父类
        QPainter painter(this);

        //设置画笔颜色
        painter.setPen(QPen(Qt::red));

        //画出字句
        painter.drawText(rect(), Qt::AlignCenter, text);

        //结束
        return;
    }

    //设置画家
    QPainter painter(this);

    //画出背景
    QPixmap p1(":/image/levone_bg.png");

    //设置背景的大小
    painter.drawPixmap(0,0,1024,576,p1);

    //输出相关信息
    showInfo(&painter);

    //循环遍历塔位置的列表
    foreach(const TowerPosition &towerPos, m_towerPositionsList)
        towerPos.draw(&painter);

    //循环遍历塔的列表
    foreach(Tower1 *tower, tower1_list)
        tower->draw(&painter);

    //循环遍历路径点的列表1
    foreach(WayPoint *wp, m_wayPointsList1)
        wp->draw(&painter);

    //循环遍历路径点的列表2
    foreach(WayPoint *wp, m_wayPointsList2)
        wp->draw(&painter);

    //循环遍历路径点的列表3
    foreach(WayPoint *wp, m_wayPointsList3)
        wp->draw(&painter);

    //循环遍历敌人列表
    foreach(Target1 *enemy, target1_list)
        enemy->draw(&painter);

    //循环遍历子弹列表
    foreach (Bullet *bullet, m_bulletList)
        bullet->draw(&painter);

}

void LevelOne::updateMap()
{

    //循环遍历敌人列表，让敌人移动
    foreach (Target1 *enemy, target1_list)
        enemy->move();

    //循环遍历塔列表，让塔攻击敌人
    foreach (Tower1 *tower, tower1_list)
        tower->checkEnemyInRange();

    //更新界面
    update();
}

void LevelOne::triggerwave()
{

    //加载敌人
    loadWave();
}

void LevelOne::showInfo(QPainter *painter)
{

    //保存画笔
    painter->save();

    //设置画笔颜色
    painter->setPen(Qt::white);

    //画出需要输出的信息
    painter->drawText(QRect(385,10,2000,50),QString("源石 : %1    侵略 : %2    守卫建筑生命 : %3").arg(fee).arg(m_waves).arg(health));

    //还原画笔
    painter->restore();
}

void LevelOne::loadTowerPositions()
{

    //加载塔位置的全部18个点
    QPoint pos[] =
    {

        //左上
        QPoint(205,114),
        QPoint(280,114),
        QPoint(355,114),

        //中上
        QPoint(435,114),
        QPoint(510,114),
        QPoint(585,114),

        //右上
        QPoint(665,114),
        QPoint(740,114),
        QPoint(815,114),

        //左下
        QPoint(135,399),
        QPoint(225,399),
        QPoint(315,399),

        //中下
        QPoint(419,399),
        QPoint(509,399),
        QPoint(599,399),

        //右下
        QPoint(704,399),
        QPoint(794,399),
        QPoint(884,399),
    };

    //设置数组长度，即遍历次数
    int len	= sizeof(pos) / sizeof(pos[0]);

    //循环遍历输入进列表
    for (int i = 0; i < len; ++i)
        m_towerPositionsList.push_back(pos[i]);
}

void LevelOne::mousePressEvent(QMouseEvent *event)
{

    //鼠标点击反馈位置
    QPoint pressPos = event->pos();

    //塔位置列表的开始
    auto it = m_towerPositionsList.begin();

    //循环判断鼠标点击位置是否在塔位置的列表中，结束条件为最后一个位置与点击位置不同
    while (it != m_towerPositionsList.end())
    {

        //如果满足源石数量足够、点击位置在范围内、原位置没有塔，就可以创建新塔
        if (canBuyTower() && it->containPoint(pressPos) && !it->hasTower()){

            int r = rand();


            if(r%2==0){

            QMediaPlayer * player = new QMediaPlayer;
            player->setMedia(QUrl("../big_res/amiya_set1.mp3"));
            player->setVolume(60);
            player->play();

            }

            else if(r%2!=0){

                QMediaPlayer * player = new QMediaPlayer;
                player->setMedia(QUrl("../big_res/amiya_set2.mp3"));
                player->setVolume(60);
                player->play();

            }

            //现在此位置上有塔
            it->setHasTower();

            //建造一个塔消耗源石
            fee-=2;

            //中心位置
            QPoint centerpoint=it->centerPos();

            //选项圈
            SelectionCircle *c = new SelectionCircle(it->centerPos(),":/pictures/pictures/selectioncircle.png");
            QPainter painter(this);
            c->draw(&painter);

            //建立塔1-阿米娅
            Tower1 *tower1 = new Tower1(centerpoint,this,":/image/tower1.png");

            //放入到塔1的列表中
            tower1_list.push_back(tower1);

            //更新页面
            update();

            //退出循环
            break;
        }

        //次数增加
        ++it;
    }
}

bool LevelOne::canBuyTower() const
{

    //如果源石数比消耗费用大就可以建造塔
    if (fee >= 2)

        //返回真
        return true;

    //返回假
    return false;
}

void LevelOne::addWayPoints()
{

    //路径1
    WayPoint *wayPoint1 = new WayPoint(QPoint(100, 185));
    m_wayPointsList1.push_back(wayPoint1);

    WayPoint *wayPoint2 = new WayPoint(QPoint(900, 185));
    m_wayPointsList1.push_back(wayPoint2);
    wayPoint2->setNextWayPoint(wayPoint1);

    //路径2
    WayPoint *wayPoint3 = new WayPoint(QPoint(75, 260));
    m_wayPointsList2.push_back(wayPoint3);

    WayPoint *wayPoint4 = new WayPoint(QPoint(925, 260));
    m_wayPointsList2.push_back(wayPoint4);
    wayPoint4->setNextWayPoint(wayPoint3);

    //路径3
    WayPoint *wayPoint5 = new WayPoint(QPoint(50, 330));
    m_wayPointsList3.push_back(wayPoint5);

    WayPoint *wayPoint6 = new WayPoint(QPoint(950, 330));
    m_wayPointsList3.push_back(wayPoint6);
    wayPoint6->setNextWayPoint(wayPoint5);
}

void LevelOne::getHpDamage(int damage = 1)
{

    //生命值减去损害值
    health-=damage;

    //如果生命值小于等于0则游戏结束
    if (health == 0){

        QMediaPlayer * player = new QMediaPlayer;
        player->setMedia(QUrl("../big_res/b_ui_lose.wav"));
        player->setVolume(60);
        player->play();

        doGameOver();
        }

    return;
}

void LevelOne::removedEnemy(Target1 *enemy)
{

    //删除敌人
    Q_ASSERT(enemy);

    //从敌人列表中删除掉敌人
    target1_list.removeOne(enemy);

    //执行删除
    delete enemy;

    //如果敌人列表空
    if (target1_list.empty())
    {

        //敌人波数增加
        ++m_waves;

        //继续进行下一波敌人进攻
        if (!loadWave())
        {

            //如果没有下一波则任务完成
            m_gameWin = true;
        }
    }
}

bool LevelOne::loadWave()
{

    //如果敌人波数大于等于3波，则任务结束
    if (m_waves >= 3){

        QMediaPlayer * player = new QMediaPlayer();
        player->setMedia(QUrl("../big_res/b_ui_win.wav"));
        player->setVolume(60);
        player->play();

        return false;
    }

    //建立三条路线的列表，逆序开始
    WayPoint *startWayPoint1 = m_wayPointsList1.back();
    WayPoint *startWayPoint2 = m_wayPointsList2.back();
    WayPoint *startWayPoint3 = m_wayPointsList3.back();

    //设置敌人进攻时间间隔
    int enemyStartInterval[] = { 1000,3000,5000,6000,7000,8000 };

    //循环加载
    for (int i = 0; i < 6; ++i)
    {

        //三条路线上的敌人们
        Target1 *enemy1 = new Target1(startWayPoint1, this, ":/image/target1.png");
        Target1 *enemy2 = new Target1(startWayPoint2, this, ":/image/target1.png");
        Target1 *enemy3 = new Target1(startWayPoint3, this, ":/image/target1.png");

        //添加到敌人列表中去
        target1_list.push_back(enemy1);
        QTimer::singleShot(enemyStartInterval[i], enemy1, SLOT(doActivate()));

        target1_list.push_back(enemy2);
        QTimer::singleShot(enemyStartInterval[i], enemy2, SLOT(doActivate()));

        target1_list.push_back(enemy3);
        QTimer::singleShot(enemyStartInterval[i], enemy3, SLOT(doActivate()));

    }

    return true;
}

void LevelOne::addBullet(Bullet *bullet)
{

    Q_ASSERT(bullet);

    //将子弹添加到列表中
    m_bulletList.push_back(bullet);
}

void LevelOne::removedBullet(Bullet *bullet)
{

    Q_ASSERT(bullet);

    //将子弹从列表中移除
    m_bulletList.removeOne(bullet);

    //删除子弹
    delete bullet;
}

void LevelOne::awardgold(int gold)
{

    //源石加上奖励金
    fee+=gold;
}

QList<Target1 *> LevelOne::enemyList() const
{

    //返回敌人1列表
    return target1_list;
}

void LevelOne::doGameOver()
{

    //结束游戏
    m_gameEnd=true;
}
