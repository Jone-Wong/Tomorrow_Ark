#include "bullet.h"
#include "target1.h"
#include "levelone.h"
#include <QPainter>
#include <QPropertyAnimation>


Bullet::Bullet(QPoint startPos, QPoint targetPoint, int damage, Target1 *target,
               LevelOne *game,  QString filename)
    : m_startPos(startPos)
    , m_targetPos(targetPoint)
    , m_currentPos(startPos)
    , m_target(target)
    , m_game(game)
    , m_damage(damage)
{

    QPixmap p(filename);
    m_sprite=p;

    //图片本身大小
    ms_fixedSize=QSize(m_sprite.width(),m_sprite.height());
}

void Bullet::draw(QPainter *painter)
{

    //在当前位置画出图片
    painter->drawPixmap(m_currentPos, m_sprite);

}

void Bullet::move()
{

    // 100毫秒内击中敌人
    static const int duration = 100;

    //运动动画
    QPropertyAnimation *animation = new QPropertyAnimation(this, "m_currentPos");

    //动画时长
    animation->setDuration(duration);

    //动画开始
    animation->setStartValue(m_startPos-QPoint(ms_fixedSize.width()/2,ms_fixedSize.height()/2));

    //动画结束
    animation->setEndValue(m_targetPos);

    //动画连接效果
    connect(animation, SIGNAL(finished()), this, SLOT(hitTarget()));

    //执行动画
    animation->start();
}

void Bullet::hitTarget()
{
    // 这样处理的原因是:
    // 可能多个炮弹击中敌人,而其中一个将其消灭,导致敌人delete
    // 后续炮弹再攻击到的敌人就是无效内存区域
    // 因此先判断下敌人是否还有效
    if (m_game->enemyList().indexOf(m_target) != -1)
        m_target->getDamage(m_damage);
    m_game->removedBullet(this);
}

void Bullet::setCurrentPos(QPoint pos)
{

    //修改当前位置
    m_currentPos = pos;
}

QPoint Bullet::currentPos()
{

    //得到当前位置
    return m_currentPos;
}
