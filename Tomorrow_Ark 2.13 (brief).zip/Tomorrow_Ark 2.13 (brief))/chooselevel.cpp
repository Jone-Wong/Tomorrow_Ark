#include "chooselevel.h"
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QMediaPlayer>
#include <QMovie>
#include <QDebug>
#include <QTimer>
#include "s2c_button.h"
#include "levtwo_button.h"
#include "leveltwo.h"
#include "lucky.h"

ChooseLevel::ChooseLevel(QWidget *parent) : QMainWindow(parent)
{
    //设置选择关卡界面大小
    this->setFixedSize(1024,576);

    //设置对象
    player = new QMediaPlayer;

    connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));

    //标注路径
    player->setMedia(QUrl("../big_res/Arknights_2.mp3"));

    //设置音量
    player->setVolume(0);

    //开始播放
    player->play();


    //设置次界面背景动画
    movie = new QMovie(this);

    //文件较大，故使用相对路径/////////导出程序时不要忘记附带视频///////////
    movie->setFileName(QString("../big_res/Arknights_2.gif"));

    //开始播放
    movie->start();

    //计时，并定时刷新界面，保证流畅性
    QTimer * timer = new QTimer (this);
    connect (timer, &QTimer::timeout, this, &ChooseLevel::updateScence);

    //每十毫秒刷新一次界面
    timer->start(10);


    //设置返回按钮
    S2C_Button *back_btn = new S2C_Button(":/image/button.png");

    //设置按钮父类
    back_btn->setParent(this);

    //返回按钮位置
    back_btn->move(850,380);

    //返回按钮链接主界面，以及弹跳效果
    connect(back_btn,&S2C_Button::clicked,this,[=](){

        //弹跳效果
        back_btn->zoomdown();
        back_btn->zoomup();

        //设置延时，以便看到效果
        QTimer::singleShot(300,this,[=](){
            emit chooseBack();
        });
    });


    //设置抽卡系统按钮
    S2C_Button * lucky_btn = new S2C_Button(":/image/lucky_button.png");

    //声明抽卡系统界面
    Lucky * findcard = new Lucky;

    //设置按钮的父类和位置
    lucky_btn ->setParent(this);

    lucky_btn ->move(570,380);

    //设置点击按钮的效果
    connect(lucky_btn,&S2C_Button::clicked,this,[=](){

        //弹跳效果
        lucky_btn->zoomdown();
        lucky_btn->zoomup();

        player->setVolume(0);

        //设置延时，以便看到效果
        QTimer::singleShot(300,this,[=](){

            this->hide();
            findcard->show();
        });
    });

    //返回界面
    connect(findcard,&Lucky::chooseBack,this,[=](){

        player->setVolume(30);

        //界面的隐藏和显现
        findcard->hide();
        this->show();
    });



    //导入第二关按钮图像
    Levtwo_Button * lvtwobtn = new Levtwo_Button(":/image/level_two.png");

    //设置第二关按钮父类和位置
    lvtwobtn->setParent(this);
    lvtwobtn->move(310,380);

    //设置第二关背景
    LevelTwo * levtwo = new LevelTwo;

    connect(lvtwobtn,&QPushButton::clicked,this,[=](){

        //第二关按钮弹跳效果
        lvtwobtn->zoomdown();
        lvtwobtn->zoomup();

        //设置时间间隔
        QTimer::singleShot(300,this,[=](){

            //画面的隐藏与显现
            //this->hide();
            levtwo->show();
        });
    });


}

void ChooseLevel::paintEvent(QPaintEvent *){

    //选择关卡界面
    QPainter painter(this);

    //导入选择关卡界面视频
    painter.drawPixmap(0,0,width(),height(), movie->currentPixmap());
}


void ChooseLevel::updateScence(){

    //刷新
    update();
}
