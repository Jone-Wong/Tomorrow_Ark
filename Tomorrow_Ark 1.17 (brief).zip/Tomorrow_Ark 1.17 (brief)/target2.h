#ifndef TARGET2_H
#define TARGET2_H

#include <QObject>
#include <QPropertyAnimation>
#include <QPoint>
#include <QPixmap>
#include <QPainter>

class Target2 : public QObject
{
    Q_OBJECT
public:
    Target2(QPoint startPos, QPoint endPos, QString fileName);
    void move();
    void draw(QPainter * painter);
private:
    QPoint startPos;
    QPoint endPos;
    QPoint currentPos;
    QPixmap pixmap;
    qreal speed;
signals:

};

#endif // TARGET2_H
