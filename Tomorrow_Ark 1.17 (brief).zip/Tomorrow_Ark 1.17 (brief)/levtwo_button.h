#ifndef LEVTWO_BUTTON_H
#define LEVTWO_BUTTON_H

#include <QWidget>
#include <QPushButton>

class Levtwo_Button : public QPushButton
{
    Q_OBJECT
public:
    Levtwo_Button(QString pix);
    void zoomup();
    void zoomdown();

signals:

};

#endif // LEVTWO_BUTTON_H
