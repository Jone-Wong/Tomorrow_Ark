#ifndef CHOOSE_LEVEL_H
#define CHOOSE_LEVEL_H

#include <QMainWindow>
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>

class ChooseLevel : public QMainWindow
{
    Q_OBJECT
public:
    void paintEvent(QPaintEvent*);
    explicit ChooseLevel(QWidget *parent = nullptr);

signals:
    void chooseBack();

};

#endif // CHOOSE_LEVEL_H
