#ifndef LEVELONE_H
#define LEVELONE_H

#include <QMainWindow>
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include "tower1.h"
#include <QList>
#include "target1.h"


class LevelOne : public QMainWindow
{
    Q_OBJECT
public:
   void paintEvent(QPaintEvent*);
   explicit LevelOne(QWidget *parent = nullptr);
   void set_tower1();
   void addTarget();
   void updateScence();
private:
   QList<Tower1 *> tower1_list;
   QList<Target1*> target1_list;

signals:

};

#endif // LEVELONE_H
