#include "leveltwo.h"
#include <QPainter>
#include "settvr_button.h"
#include <QTimer>
#include "tower1.h"
#include "target1.h"
#include "levelone.h"
#include "target2.h"

LevelTwo::LevelTwo(QWidget *parent) : QMainWindow(parent)
{
    //设置图片大小
    this->setFixedSize(1024,576);

    //设置创建_塔1d-德克萨斯_的按钮
    Settvr_Button * setTower1 = new Settvr_Button(":/image/settower_button.png");

    //设置按钮的父类、位置
    setTower1->setParent(this);
    setTower1->move(225,5);

    //点击按钮
    connect(setTower1,&QPushButton::clicked,this,[=](){

        //按钮跳动
        setTower1->zoomdown();
        setTower1->zoomup();

        //添加_塔1d-德克萨斯_和_敌人1-小车_
        LevelTwo::addTarget1();
        LevelTwo::addTarget2();
        LevelTwo::set_tower1();

        //        connect(setTower1,&Settvr_Button::clicked,this,&LevelOne::addTarget);
        //        connect(setTower1,&Settvr_Button::clicked,this,&LevelOne::set_tower1);

    });

    //计时，并定时刷新界面，保证流畅性
    QTimer * timer = new QTimer (this);
    connect (timer, &QTimer::timeout, this, &LevelTwo::updateScence);
    timer->start(10);
}

void LevelTwo::paintEvent(QPaintEvent*){

    //选择关卡界面
    QPainter painter(this);

    //导入选择关卡界面图片
    QPixmap pixmap(":/image/levtwo_bg.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);

    //循环遍历形成动画
    foreach(Tower1 * tower, tower1_list){
        tower -> draw(&painter);
    }

    //循环遍历形成动画
    foreach(Target1 * target, target1_list){
        target -> draw(&painter);
    }

    //循环遍历形成动画
    foreach(Target2 * target, target2_list){
        target -> draw(&painter);
    }

}

void LevelTwo::set_tower1(){

    //创建_塔1d-德克萨斯_，设置位置以及图像
    Tower1 * a_new_tower = new Tower1(QPoint (230,10),":/image/tower1d.png");

    //存入list中
    tower1_list.push_back(a_new_tower);

    //刷新
    update();
}

void LevelTwo::addTarget1(){

    //创建_敌人1-小车_，设置位置以及图像
    Target1 * target = new Target1(QPoint (900,115), QPoint(0,115), ":/image/target1.png");

    //存入list中
    target1_list.push_back(target);

    //让敌人1移动
    target->move();

    //刷新
    update();
}

void LevelTwo::addTarget2(){

    //创建_敌人2-小车_，设置位置以及图像
    Target2 * target = new Target2(QPoint (900,185), QPoint(0,185), ":/image/target2.png");

    //存入list中
    target2_list.push_back(target);

    //让敌人2移动
    //target->move();

    //刷新
    update();
}

void LevelTwo::updateScence(){

    foreach(Target2 * target, target2_list){

        target -> move();
    }

    //刷新
    update();
}
