#ifndef S2C_BUTTON_H
#define S2C_BUTTON_H

#include <QWidget>
#include <QPushButton>

class S2C_Button : public QPushButton
{
    Q_OBJECT
public:
    S2C_Button(QString pix);
    void zoomdown();
    void zoomup();

signals:

};

#endif // S2C_BUTTON_H
