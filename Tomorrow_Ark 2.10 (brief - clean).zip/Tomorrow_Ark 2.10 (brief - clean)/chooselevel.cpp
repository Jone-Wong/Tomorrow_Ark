#include "chooselevel.h"
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>
#include <QTimer>
#include "s2c_button.h"
#include "levtwo_button.h"
#include "leveltwo.h"
#include "lucky.h"

ChooseLevel::ChooseLevel(QWidget *parent) : QMainWindow(parent)
{
    //设置选择关卡界面大小
    this->setFixedSize(1024,576);

    //设置返回按钮
    S2C_Button *back_btn = new S2C_Button(":/image/button.png");

    //设置按钮父类
    back_btn->setParent(this);

    //返回按钮位置
    back_btn->move(850,430);

    //返回按钮链接主界面，以及弹跳效果
    connect(back_btn,&S2C_Button::clicked,this,[=](){

        //弹跳效果
        back_btn->zoomdown();
        back_btn->zoomup();

        //设置延时，以便看到效果
        QTimer::singleShot(300,this,[=](){
            emit chooseBack();
        });
    });


    //设置抽卡系统按钮
    S2C_Button * lucky_btn = new S2C_Button(":/image/lucky_button.png");

    //声明抽卡系统界面
    Lucky * findcard = new Lucky;

    //设置按钮的父类和位置
    lucky_btn ->setParent(this);

    lucky_btn ->move(445,375);

    //设置点击按钮的效果
    connect(lucky_btn,&S2C_Button::clicked,this,[=](){

        //弹跳效果
        lucky_btn->zoomdown();
        lucky_btn->zoomup();

        //设置延时，以便看到效果
        QTimer::singleShot(300,this,[=](){

            this->hide();
            findcard->show();
        });
    });

    //返回界面
    connect(findcard,&Lucky::chooseBack,this,[=](){


        //界面的隐藏和显现
        findcard->hide();
        this->show();
    });



    //导入第一关按钮图像
    Levtwo_Button * lvtwobtn = new Levtwo_Button(":/image/level_two.png");

    //设置第一关按钮父类和位置
    lvtwobtn->setParent(this);
    lvtwobtn->move(280,230);

    //设置第二关背景
    LevelTwo * levtwo = new LevelTwo;

    connect(lvtwobtn,&QPushButton::clicked,this,[=](){

        //第二关按钮弹跳效果
        lvtwobtn->zoomdown();
        lvtwobtn->zoomup();

        //设置时间间隔
        QTimer::singleShot(300,this,[=](){

            //画面的隐藏与显现
            this->hide();
            levtwo->show();
        });
    });


}

void ChooseLevel::paintEvent(QPaintEvent *){

    //选择关卡界面
    QPainter painter(this);

    //导入选择关卡界面图片
    QPixmap pixmap(":/image/level.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}
