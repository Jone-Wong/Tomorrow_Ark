#ifndef TARGET1_H
#define TARGET1_H

#include <QObject>
#include <QPropertyAnimation>
#include <QPoint>
#include <QPixmap>
#include <QPainter>
#include "tower1.h"
#include "levelone.h"
#include "waypoint.h"

class LevelOne;
class WayPoint;
class Tower1;

class Target1 : public QObject
{
    Q_OBJECT
public:
    Target1(WayPoint *startWayPoint,  LevelOne *game, QString filename);
    void draw(QPainter *painter);
    void move();
    void getDamage(int damage);
    void getRemoved();
    QPoint pos() const;
    void getAttacked(Tower1 *attacker);
    void gotLostSight(Tower1 *attacker);
public slots:
    void doActivate();
private:
    bool			m_active;
    int				m_maxHp;
    int				m_currentHp;
    qreal			m_walkingSpeed;
    QPoint			m_pos;
    WayPoint *		m_destinationWayPoint;
    LevelOne *	m_game;
    QPixmap	m_sprite;
    QSize ms_fixedSize;
    QList<Tower1 *>	m_attackedTowersList;

};

#endif // TARGET1_H


/*

#include <QObject>
#include <QPoint>
#include <QSize>
#include <QPixmap>
class WayPoint;
class battlefield1;
class tower;
class Enemy : public QObject
{
    Q_OBJECT
public:
    Enemy(WayPoint *startWayPoint,  battlefield1 *game, QString filename);//√
//    ~Enemy();
    void draw(QPainter *painter);//√
    void move();
    void getDamage(int damage);
    void getRemoved();
    QPoint pos() const;
    void getAttacked(tower *attacker);
    void gotLostSight(tower *attacker);
public slots:
    void doActivate();
private:
    bool			m_active;
    int				m_maxHp;
    int				m_currentHp;
    qreal			m_walkingSpeed;
//    qreal			m_rotationSprite;
    QPoint			m_pos;
    WayPoint *		m_destinationWayPoint;
    battlefield1 *	m_game;
    QPixmap	m_sprite;
    QSize ms_fixedSize;
    QList<tower *>	m_attackedTowersList;
};

*/
