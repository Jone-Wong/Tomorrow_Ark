#ifndef STORY_H
#define STORY_H

#include <QMainWindow>
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>

class Story : public QMainWindow
{
    Q_OBJECT
public:
    void paintEvent(QPaintEvent*);
    explicit Story(QWidget *parent = nullptr);

signals:
    void chooseBack();
};

#endif // STORY_H
