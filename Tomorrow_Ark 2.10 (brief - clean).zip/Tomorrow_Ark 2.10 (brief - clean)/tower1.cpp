#include "tower1.h"
#include <QPoint>
#include <QPixmap>
#include <QPainter>
#include <QTimer>
#include <QtMath>
#include "target1.h"
#include "levelone.h"
#include "utility.h"


Tower1::Tower1(QPoint _pos,LevelOne *game ,QString pixfilename):mgame(game)
{

    //位置
    this->pos=_pos;

    //画塔
    QPixmap p1(pixfilename);

    //图片大小
    ms_fixedSize=QSize(p1.width(),p1.height());

    //初始化
    this->pixmap=p1;

    //攻击范围
    firerange=150;

    //攻击速率
    firerate=400;

    //造成伤害
    damage=10;

    //攻击判断
    mattacking=false;

    mrotationpixmap=0.0;

    //选择敌人判断
    mchooseEnemy=NULL;

    //攻击时间
    mfireRateTimer = new QTimer(this);
    connect(mfireRateTimer,SIGNAL(timeout()),SLOT(shootWeapon()));
}

void Tower1::draw(QPainter *painter)
{

    //保存画笔
    painter->save();

    //画笔颜色
    painter->setPen(Qt::blue);

    // 绘制攻击范围
    painter->drawEllipse(pos, firerange, firerange);

    //painter->drawEllipse(pos,1,1);
    // 绘制偏转坐标,由中心+偏移=左上
    // 尺寸大小派上用场了,当然也可以直接获取图片大小,是一样的

    QPixmap sprite(":/image/tower1.png");
    static const QPoint offsetPoint(-sprite.width()/2,-sprite.height()/2);

    // 绘制炮塔并选择炮塔
    // 这里将坐标原点移到pos,绘制的适合,就要加上那个偏移点到左上角
    painter->translate(pos);
    painter->drawPixmap(offsetPoint, pixmap);
    painter->restore();
}

void Tower1::attackEnemy()
{

    // 启动打炮模式
    mfireRateTimer->start(firerate);
}

void Tower1::chooseEnemyForAttack(Target1 *enemy)
{

    // 选择敌人,同时设置对敌人开火
    mchooseEnemy = enemy;

    // 这里启动timer,开始打炮
    attackEnemy();

    // 敌人自己要关联一个攻击者,这个用QList管理攻击者,因为可能有多个//this function needs to be checked in enemy
    mchooseEnemy->getAttacked(this);
}

void Tower1::shootWeapon()
{

    // 每次攻击,产生一个子弹
    // 子弹一旦产生,交由m_game管理,进行绘制
    Bullet *bullet = new Bullet (pos, mchooseEnemy->pos(), damage, mchooseEnemy, mgame,":/image/bullet.png");

    //    QPainter *pa;
    //    pa->save();
    //    pa->setPen(Qt::red);
    //    pa->drawEllipse(pos,1,1);
    //    pa->restore();

    //移动子弹
    bullet->move();

     //this function needs to be checked in LevelOne
    mgame->addBullet(bullet);
}

void Tower1::targetKilled()
{

    // 目标死亡时,也需要取消关联
    if (mchooseEnemy)
        mchooseEnemy = NULL;

    // 取消攻击
    mfireRateTimer->stop();
    mrotationpixmap = 0.0;
}

void Tower1::lostSightOfEnemy()
{

    // 当敌人脱离炮塔攻击范围,要将炮塔攻击的敌人关联取消
    // 同时取消攻击
    //thie function needs to be checked in target1
    mchooseEnemy->gotLostSight(this);

    if (mchooseEnemy)
        mchooseEnemy = NULL;

    mfireRateTimer->stop();
    mrotationpixmap = 0.0;
}

void Tower1::checkEnemyInRange()
{

    if (mchooseEnemy)
    {

        QVector2D normalized(mchooseEnemy->pos() - pos);
        normalized.normalize();

        //        mrotationpixmap = qRadiansToDegrees(qAtan2(normalized.y(), normalized.x())) - 90;
        // 如果敌人脱离攻击范围
        if (!crash(pos, firerange, mchooseEnemy->pos(), 1))
            lostSightOfEnemy();
    }

    else
    {

        // 遍历敌人,看是否有敌人在攻击范围内
        QList<Target1 *> enemyList = mgame->enemyList();

        foreach (Target1 *enemy, enemyList)
        {

            if (crash(pos,firerange, enemy->pos(), 1))
            {

                chooseEnemyForAttack(enemy);
                break;
            }
        }
    }
}
