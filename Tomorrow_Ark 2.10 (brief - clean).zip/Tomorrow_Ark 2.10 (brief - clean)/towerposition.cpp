#include "towerposition.h"
#include <QPainter>
#include <iostream>


TowerPosition::TowerPosition(QPoint pos) :  m_pos(pos), m_hasTower(false)
{

}

const QPoint TowerPosition::centerPos() const
{

    //设置中心位置
    QPoint offsetPoint(ms_fixedSize.width() / 2, ms_fixedSize.height() / 2);
    return m_pos + offsetPoint;
}

bool TowerPosition::containPoint(const QPoint &pos) const
{

    //判断此位置是否有塔
    bool isXInHere = m_pos.x() < pos.x() && pos.x() < (m_pos.x() + 200); //ms_fixedSize.width()
    bool isYInHere = m_pos.y() < pos.y() && pos.y() < (m_pos.y() +100 ); //ms_fixedSize.height()

    return isXInHere && isYInHere;
}

bool TowerPosition::hasTower() const
{

    //返回是否有塔
    return m_hasTower;
}

void TowerPosition::setHasTower(bool hasTower)
{

    //设置变无塔或有塔
    m_hasTower = hasTower;
}

void TowerPosition::draw(QPainter *painter) const
{

    //画塔
    painter -> drawPixmap(m_pos.x(), m_pos.y(), m_sprite);
}

